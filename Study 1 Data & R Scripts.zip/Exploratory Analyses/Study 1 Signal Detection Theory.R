#load packages
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez, janitor, afex, psycho)

#options
options(scipen = 999)

#read data
accuracy_data <- read.csv(here::here("Study1_accuracy_data_file_155.csv"))

#select subset of trials where people responded
accuracy_data2 <- subset(accuracy_data, accuracy_data$response == 30 | accuracy_data$response == 38)


#create new variables which code each trial as hit miss false alarm or correct reject, based on anger as hit
accuracy_data2 <- accuracy_data2 %>% 
mutate(Hits = if_else(correct == 1 & Emotion == 2, 1, 0)) %>%
mutate(Misses = if_else(correct == 0 & Emotion == 2, 1, 0)) %>%
mutate(FalseAlarm = if_else(correct == 0 & Emotion == 1, 1, 0)) %>%
mutate(CorrectReject = if_else(correct == 1 & Emotion == 1, 1, 0))

#aggregate dataframe
data_agg <- aggregate(accuracy_data2[12:15], by = list(accuracy_data2$ModelGender, accuracy_data2$MaskStatus, accuracy_data2$subject), FUN = mean)

#easy way to make new factors with the right names
data_agg$subject <- as.factor(data_agg$Group.3)
data_agg$ModelGender <- as.factor(data_agg$Group.1)
data_agg$MaskStatus <- as.factor(data_agg$Group.2)

#correct 0 to 0.01 and 1 to .99 to allow for tests to compute
data_agg <- data_agg %>%
  mutate(Hits_corrected = abs(if_else(Hits == 0 | Hits == 1, Hits - 0.0001, Hits))) %>%
  mutate(Miss_corrected = abs(if_else(Misses == 0 | Misses == 1, Misses - 0.0001, Misses))) %>%
  mutate(FalseAlarm_corrected = abs(if_else(FalseAlarm == 0 | FalseAlarm == 1, FalseAlarm - 0.0001, FalseAlarm))) %>%
  mutate(CorrectReject_corrected = abs(if_else(CorrectReject == 0 | CorrectReject == 1, CorrectReject - 0.0001, CorrectReject)))

#compute indicates and combine dataframews
indices <- psycho::dprime(data_agg$Hits_corrected, data_agg$FalseAlarm_corrected, data_agg$Miss_corrected, data_agg$CorrectReject_corrected)
data_agg <- cbind(data_agg, indices)

#remove 182 for the t tests 
data_agg <- subset(data_agg, data_agg$subject != 182)

##do anova and tests for the dprime measure
anova1 <- afex::aov_ez("subject", "dprime", data_agg, within = c( "ModelGender", "MaskStatus"), anova_table = list(es = "pes"))
#shows results
anova1


#get summarystats
#mask level
aggregate(data_agg$dprime, by = list(data_agg$MaskStatus), FUN = mean)
aggregate(data_agg$dprime, by = list(data_agg$MaskStatus), FUN = sd)#higher in no mask
#gender
aggregate(data_agg$dprime, by = list(data_agg$ModelGender), FUN = mean)
aggregate(data_agg$dprime, by = list(data_agg$ModelGender), FUN = sd)
#higher in males




#same for the beta
anova2 <- afex::aov_ez("subject", "beta", data_agg, within = c("ModelGender", "MaskStatus"), anova_table = list(es = "pes"))
#shows results
anova2


#summary stats
aggregate(data_agg$beta, by = list(data_agg$MaskStatus), FUN = mean) #unmasked larger
aggregate(data_agg$beta, by = list(data_agg$MaskStatus), FUN = sd) #unmasked larger

#cohens d
cohen.d(data_agg$beta ~ data_agg$MaskStatus | Subject(subject), paired = TRUE)


###do log beta
#just as sanity check
data_agg$logbeta <- log(data_agg$beta)
anova3 <- afex::aov_ez("subject", "logbeta", data_agg, within = c("ModelGender", "MaskStatus"), anova_table = list(es = "pes"))
#shows results
anova3
#virtually same results as beta

cohen.d(data_agg$logbeta ~ data_agg$MaskStatus | Subject(subject), paired = TRUE)


##do anova and tests for the dprime measure
anova4 <- afex::aov_ez("subject", "bppd", data_agg, within = c( "ModelGender", "MaskStatus"), anova_table = list(es = "pes"))
#shows results
anova4


#get summarystats
#mask level
aggregate(data_agg$bppd, by = list(data_agg$MaskStatus), FUN = mean) #higher in no mask
aggregate(data_agg$bppd, by = list(data_agg$MaskStatus), FUN = sd)

#cohens d
cohen.d(data_agg$bppd ~ data_agg$MaskStatus | Subject(subject), paired = TRUE)

