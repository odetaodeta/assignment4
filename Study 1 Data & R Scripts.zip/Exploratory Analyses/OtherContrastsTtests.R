#setup
#packages
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez, gridExtra)

#load functions, must be in same folder
source("trimmingFixedFunctions.R")
source("transformationFunctions.R")
source("trimmingDataFunctions.R")
source("convenienceFunctions.R")
source("multiverseAnalyses.R")
source("ANOVAfreqMultiverse.R")

#load general data
dataStudy1<- read.csv(here::here("Study1_data_file_155.csv"))
df_permutation_male_2x2 <- read.csv(here::here("OtherContrastsMale.csv"))
df_permutation_female_2x2 <- read.csv(here::here("OtherContrastsFemale.csv"))
df_male_2x2 <- subset(dataStudy1, dataStudy1$ModelGender == "1")
df_female_2x2 <- subset(dataStudy1, dataStudy1$ModelGender == "2")

#set length permutation
permutation <- 1:500


####Male#####

#run multiverse analysis
df_male_2x2_mult <- multiverse.t.test(df_male_2x2, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "Emotion", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)



#create a copy of the dataset
df_permutation_male_2x2_2 <- df_permutation_male_2x2


###Effect Size Calculations###
#get median effect sizes of observed effect
#positive effect -> smaller RT for male, as expected
median(df_male_2x2_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_male_2x2_2_perm_median <- aggregate(df_permutation_male_2x2_2$estimate, list(df_permutation_male_2x2_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_male_2x2_2_perm_median$x) >= abs(median(df_male_2x2_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2_male_p_val <- multiverse.prop(df_male_2x2_mult, type = "frequentist", df_male_2x2_mult$p.value))
(df2x2_male_pval_number <- df2x2_male_p_val * nrow(df_male_2x2_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_male_2x2_2$numbersignificant <- ifelse(df_permutation_male_2x2_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2_male_pval_perm <- aggregate(df_permutation_male_2x2_2$numbersignificant, list(df_permutation_male_2x2_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2_male_pval_perm_prop <- ifelse(df2x2_male_pval_perm$x >= df2x2_male_pval_number, 1, 0)
sum(df2x2_male_pval_perm_prop)

#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.
#we predict a positive effect

#calculate proportion for observed data
df_2x2_male_observed_sign <- subset(df_male_2x2_mult, df_male_2x2_mult$estimate > 0)
(df2x2_male_sign_val <- multiverse.prop(df_2x2_male_observed_sign, type = "frequentist", df_2x2_male_observed_sign$p.value))
df2x2_male_sign_pval_number <- (df2x2_male_sign_val * nrow(df_2x2_male_observed_sign))


#and for permutated data
df_2x2_male_sign <- subset(df_permutation_male_2x2_2, df_permutation_male_2x2_2$estimate > 0)
#create summarised dataframe with one row by iteration
(df2x2_male_sign_pval <- aggregate(df_2x2_male_sign$numbersignificant, list(df_2x2_male_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df2x2_male_sign_prop <- ifelse(df2x2_male_sign_pval$x >= df2x2_male_sign_pval_number , 1, 0)
sum(df2x2_male_sign_prop) 
sum(df2x2_male_sign_prop) / length(permutation)
#0/500 have an effect in the expected direction and the same or higher share of significant specifications
# p < 002


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#p = <.002
#0/500 iterations have a median effect size as extreme or more extreme. This does not take 



#####Female#####
#run multiverse analysis
df_female_2x2_mult <- multiverse.t.test(df_female_2x2, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "Emotion", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)



#create a copy of the dataset
df_permutation_female_2x2_2 <- df_permutation_female_2x2


###Effect Size Calculations###
#get median effect sizes of observed effect
#would expect smaller RT for sadness, hence negative.
median(df_female_2x2_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_female_2x2_2_perm_median <- aggregate(df_permutation_female_2x2_2$estimate, list(df_permutation_female_2x2_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_female_2x2_2_perm_median$x) >= abs(median(df_female_2x2_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2_female_p_val <- multiverse.prop(df_female_2x2_mult, type = "frequentist", df_female_2x2_mult$p.value))
(df2x2_female_pval_number <- df2x2_female_p_val * nrow(df_female_2x2_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_female_2x2_2$numbersignificant <- ifelse(df_permutation_female_2x2_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2_female_pval_perm <- aggregate(df_permutation_female_2x2_2$numbersignificant, list(df_permutation_female_2x2_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2_female_pval_perm_prop <- ifelse(df2x2_female_pval_perm$x >= df2x2_female_pval_number, 1, 0)
sum(df2x2_female_pval_perm_prop)

#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.
#we predict a positive effect

#calculate proportion for observed data
df_2x2_female_observed_sign <- subset(df_female_2x2_mult, df_female_2x2_mult$estimate > 0)
(df2x2_female_sign_val <- multiverse.prop(df_2x2_female_observed_sign, type = "frequentist", df_2x2_female_observed_sign$p.value))
df2x2_female_sign_pval_number <- (df2x2_female_sign_val * nrow(df_2x2_female_observed_sign))


#and for permutated data
df_2x2_female_sign <- subset(df_permutation_female_2x2_2, df_permutation_female_2x2_2$estimate > 0)
#create summarised dataframe with one row by iteration
(df2x2_female_sign_pval <- aggregate(df_2x2_female_sign$numbersignificant, list(df_2x2_female_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df2x2_female_sign_prop <- ifelse(df2x2_female_sign_pval$x >= df2x2_female_sign_pval_number , 1, 0)
sum(df2x2_female_sign_prop) 
sum(df2x2_female_sign_prop) / length(permutation)



#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

