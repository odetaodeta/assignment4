##Accuracy Data Analysis##
#packages
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez, janitor, afex)


options(scipen =999)

accuracy_data <- read.csv(here::here("Study1_accuracy_data_file_155.csv"))


#create dataset for t.tests
#aggregate data
accuracy_agg <- aggregate(accuracy_data$correct, list(accuracy_data$subject, accuracy_data$Emotion, accuracy_data$ModelGender, accuracy_data$MaskStatus), mean)

#as.factor with better names
accuracy_agg$Subject<- accuracy_agg$Group.1
accuracy_agg$Emotion <- as.factor(accuracy_agg$Group.2)
accuracy_agg$ModelGender <- as.factor(accuracy_agg$Group.3)
accuracy_agg$MaskStatus <- as.factor(accuracy_agg$Group.4)

#and for anovas
accuracy_data$Emotion <- as.factor(accuracy_data$Emotion)
accuracy_data$Emotion <- revalue(accuracy_data$Emotion, c("1" = "Sadness", "2" = "Anger"))
accuracy_data$ModelGender <- as.factor(accuracy_data$ModelGender)
accuracy_data$ModelGender <- revalue(accuracy_data$ModelGender, c("1" = "Male", "2" = "Female"))
accuracy_data$MaskStatus <- as.factor(accuracy_data$MaskStatus)
accuracy_data$MaskStatus <- revalue(accuracy_data$MaskStatus, c("1" = "Mask", "2" = "NoMask"))




#We will analyse error rates using a 2x2x2 repeated measures ANOVA (Emotion*ModelGender*MaskStatus).


#the anova
(ezAnova <- ezANOVA(data = accuracy_data, dv = .(correct), wid = .(subject), within = .(Emotion, ModelGender, MaskStatus)))


f.value <- ezAnova$ANOVA$F
p.value <- ezAnova$ANOVA$p
Dfn <- ezAnova$ANOVA$DFn
Dfd <- ezAnova$ANOVA$DFd


(estimate <- (f.value * Dfn) / (f.value * Dfn + Dfd))

#we are not interested in the results, we just want to use the resulting object for plotting
anova2 <- aov_ez("subject", "correct", accuracy_data, within = c("Emotion", "ModelGender", "MaskStatus"))
#shows results
anova2
#same results for both functions


#make plot
plot_accuracy <- afex_plot(anova2, x = "MaskStatus", trace = "ModelGender", panel = "Emotion", error = "within", mapping = c("color", "fill", "shape"), data_geom = geom_violin, data_arg = list(width = 0.4), point_arg = list(size = 1.5), line_arg = list(size = 1)) + theme_bw() + 
  theme(axis.title.x=element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA)) + scale_fill_manual(values=c("#E69F00", "#56B4E9")) + ggtitle("Visualisation Accuracy")

plot_accuracy 


#follow up t-test for mask * emotion interaction
accuracy_agg_2 <- aggregate(accuracy_agg$x, list(accuracy_agg$Subject, accuracy_agg$Emotion, accuracy_agg$MaskStatus), mean)
accuracy_angry <- subset(accuracy_agg_2, accuracy_agg_2$Group.2 == "2")
accuracy_sad <- subset(accuracy_agg_2, accuracy_agg_2$Group.2 == "1")



#for angry
t.test(accuracy_angry$x ~ accuracy_angry$Group.3, paired = TRUE)
cohen.d(x ~ Group.3 | Subject(Group.1), paired = TRUE, data = accuracy_angry)

#for sad
t.test(accuracy_sad$x ~ accuracy_sad$Group.3, paired = TRUE)
cohen.d(x ~ Group.3 | Subject(Group.1), paired = TRUE, data = accuracy_sad)

#"sad" = 1, "angry" = 2))
#"Male" = 1, "Female" = 2))
#"Mask" = 1, "No Mask" = 2))


#get means by cell
accuracy_summary <- aggregate(accuracy_data$correct, list(accuracy_data$Emotion, accuracy_data$ModelGender, accuracy_data$MaskStatus), mean)

accuracy_summary_sd <- aggregate(accuracy_data$correct, list(accuracy_data$Emotion, accuracy_data$ModelGender, accuracy_data$MaskStatus), sd)

accuracy_summary$Emotion <- as.factor(accuracy_summary$Group.1)
accuracy_summary$ModelGender <- as.factor(accuracy_summary$Group.2)
accuracy_summary$MaskStatus <- as.factor(accuracy_summary$Group.3)

accuracy_summary_sd$Emotion <- as.factor(accuracy_summary_sd$Group.1)
accuracy_summary_sd$ModelGender <- as.factor(accuracy_summary_sd$Group.2)
accuracy_summary_sd$MaskStatus <- as.factor(accuracy_summary_sd$Group.3)

aggregate(accuracy_data$correct, list(accuracy_data$Emotion), mean)
aggregate(accuracy_data$correct, list(accuracy_data$Emotion), sd)

aggregate(accuracy_data$correct, list(accuracy_data$ModelGender), mean)
aggregate(accuracy_data$correct, list(accuracy_data$ModelGender), sd)

aggregate(accuracy_data$correct, list(accuracy_data$MaskStatus), mean)
aggregate(accuracy_data$correct, list(accuracy_data$MaskStatus), sd)
          
