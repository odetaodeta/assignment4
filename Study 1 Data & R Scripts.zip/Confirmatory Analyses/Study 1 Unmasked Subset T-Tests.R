####Follow-up T-tests in the unmasked condition only - closest possible replication of bijlstra et al., 2010)#####

#setup
#packages
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez, gridExtra)

#load functions, must be in same folder
source("trimmingFixedFunctions.R")
source("transformationFunctions.R")
source("trimmingDataFunctions.R")
source("convenienceFunctions.R")
source("multiverseAnalyses.R")
source("ANOVAfreqMultiverse.R")

#load general data
dataStudy1 <- read.csv(here::here("Study1_data_file_155.csv"))

#set up length permutation
#make sure it is n of actual permutation
permutation <- 1:500

#####Angry Subset#####
df_permutation_angry_nomask <- read.csv(here::here("permutation_angry_nomask.csv"))
df_angry_2x2 <- subset(dataStudy1, dataStudy1$Emotion == "2")
df_angry_nomask <- subset(df_angry_2x2, df_angry_2x2$MaskStatus == "2")


#run multiverse analysis 
df_angry_nomask_mult <- multiverse.t.test(df_angry_nomask, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "ModelGender", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)


#create a copy of the dataset
df_permutation_angry_nomask_2 <- df_permutation_angry_nomask


###Effect Size Calculations###
#get median effect sizes of observed effect
median(df_angry_nomask_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_angry_nomask_2_perm_median <- aggregate(df_permutation_angry_nomask_2$estimate, list(df_permutation_angry_nomask_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_angry_nomask_2_perm_median$x) >= abs(median(df_angry_nomask_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#0/500 p < .002

###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df_angry_nomask_p_val <- multiverse.prop(df_angry_nomask_mult, type = "frequentist", df_angry_nomask_mult$p.value))
(df_angry_nomask_pval_number <- df_angry_nomask_p_val * nrow(df_angry_nomask_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_angry_nomask_2$numbersignificant <- ifelse(df_permutation_angry_nomask_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df_angry_nomask_pval_perm <- aggregate(df_permutation_angry_nomask_2$numbersignificant, list(df_permutation_angry_nomask_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df_angry_nomask_pval_perm_prop <- ifelse(df_angry_nomask_pval_perm$x >= df_angry_nomask_pval_number, 1, 0)
sum(df_angry_nomask_pval_perm_prop)

sum(df_angry_nomask_pval_perm_prop) / length(permutation)
#0/500  p < .002

#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.
#male = 1 , female = 2 -> we predict lower RT for male faces, hence a negative effect
df_angry_nomask_observed_sign <- subset(df_angry_nomask_mult, df_angry_nomask_mult$estimate < 0) 
(df_anger_nomask_sign_val <- multiverse.prop(df_angry_nomask_observed_sign, type = "frequentist", df_angry_nomask_observed_sign$p.value))
df_anger_nomask_sign__pval_number <- (df_anger_nomask_sign_val* nrow(df_angry_nomask_observed_sign))
df_anger_nomask_sign__pval_number 

df_anger_nomask_sign <- subset(df_permutation_angry_nomask_2, df_permutation_angry_nomask_2$estimate < 0)
#create summarised dataframe with one row by iteration
(df_anger_nomask_sign_pval <- aggregate(df_anger_nomask_sign$numbersignificant, list(df_anger_nomask_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df_anger_nomask_sign_prop <- ifelse(df_anger_nomask_sign_pval$x >= df_anger_nomask_sign__pval_number , 1, 0)
sum(df_anger_nomask_sign_prop)
#1/500 have an effect in the expected direction and the same or higher share of significant specifications
sum(df_anger_nomask_sign_prop) / length(permutation)
#p = .002

######Sad Subset#####
df_sad_2x2 <- subset(dataStudy1, dataStudy1$Emotion == "1")
df_sad_nomask <- subset(df_sad_2x2, df_sad_2x2$MaskStatus == "2")
df_permutation_sad_nomask <- read.csv(here::here("permutation_sad_nomask.csv"))

#run multiverse analysis 
df_sad_nomask_mult <- multiverse.t.test(df_sad_nomask, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "ModelGender", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)


#create a copy of the dataset
df_permutation_sad_nomask_2 <- df_permutation_sad_nomask


###Effect Size Calculations###
#get median effect sizes of observed effect
median(df_sad_nomask_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_sad_nomask_2_perm_median <- aggregate(df_permutation_sad_nomask_2$estimate, list(df_permutation_sad_nomask_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_sad_nomask_2_perm_median$x) >= abs(median(df_sad_nomask_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#233/500 iterations have a median effect size as extreme or more extreme
#p = .466
###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df_sad_nomask_p_val <- multiverse.prop(df_sad_nomask_mult, type = "frequentist", df_sad_nomask_mult$p.value))
(df_sad_nomask_pval_number <- df_sad_nomask_p_val * nrow(df_sad_nomask_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_sad_nomask_2$numbersignificant <- ifelse(df_permutation_sad_nomask_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df_sad_nomask_pval_perm <- aggregate(df_permutation_sad_nomask_2$numbersignificant, list(df_permutation_sad_nomask_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df_sad_nomask_pval_perm_prop <- ifelse(df_sad_nomask_pval_perm$x >= df_sad_nomask_pval_number, 1, 0)
sum(df_sad_nomask_pval_perm_prop) 
sum(df_sad_nomask_pval_perm_prop) / length(permutation)
#78/500 iterations have the same or a higher number of significant specifications
#p = .156

#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.
#male = 1 , female = 2 -> we predict lower RT for female faces, hence a positive effect
df_sad_nomask_observed_sign <- subset(df_sad_nomask_mult, df_sad_nomask_mult$estimate > 0) #there are no specificiations which give an effect > 0
(df_sadness_nomask_sign_val <- multiverse.prop(df_sad_nomask_observed_sign, type = "frequentist", df_sad_nomask_observed_sign$p.value))
df_sadness_nomask_sign__pval_number <- (df_sadness_nomask_sign_val* nrow(df_sad_nomask_observed_sign))
df_sadness_nomask_sign__pval_number 

#permutated data
df_sad_nomask_sign <- subset(df_permutation_sad_nomask_2, df_permutation_sad_nomask_2$estimate > 0)
#create summarised dataframe with one row by iteration
(df_sad_nomask_sign_pval <- aggregate(df_sad_nomask_sign$numbersignificant, list(df_sad_nomask_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df_sad_nomask_sign_prop <- ifelse(df_sad_nomask_sign_pval$x >= df_sadness_nomask_sign__pval_number , 1, 0)
sum(df_sad_nomask_sign_prop)
sum(df_sad_nomask_sign_prop) / length (permutation)
#46/500 have an effect in the expected direction and the same or higher share of significant specifications
#p = .092


###Visualisation of Effect Sizes###
##2*2 Angry##

df_angry_nomask_mult$specificationN <- seq.int(nrow(df_angry_nomask_mult))
df_permutation_angry_nomask_2$specificationN <- rep(1:126, times = 500)

#create a dataset with the median effect sizes
df_angry_nomask_plot <- aggregate(df_permutation_angry_nomask_2$estimate, list(df_permutation_angry_nomask_2$specificationN), median)

#create dataset with 2.5th quantile
df_angry_nomask_plot_2.5 <- aggregate(df_permutation_angry_nomask_2$estimate, list(df_permutation_angry_nomask_2$specificationN), FUN = function(x) quantile(x, c(.025)))

df_angry_nomask_plot_97.5 <- aggregate(df_permutation_angry_nomask_2$estimate, list(df_permutation_angry_nomask_2$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df_angry_nomask_plot$observedETA <- df_angry_nomask_mult$estimate
df_angry_nomask_plot$q0.25 <- df_angry_nomask_plot_2.5$x
df_angry_nomask_plot$q97.5 <- df_angry_nomask_plot_97.5$x
df_angry_nomask_plot_ordered <- df_angry_nomask_plot[order(df_angry_nomask_plot$observedETA),]
df_angry_nomask_plot_ordered$order <- seq.int(nrow(df_angry_nomask_plot_ordered))

colors <- c("Median Observed" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot5 <- ggplot(data = df_angry_nomask_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Median Observed")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(-1, .4) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification Anger Unmasked") +
  labs(x = "Specification",
       y = "Cohen´s D",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))



##2*2 Sad##

df_sad_nomask_mult$specificationN <- seq.int(nrow(df_sad_nomask_mult))
df_permutation_sad_nomask_2$specificationN <- rep(1:126, times = 500)

#create a dataset with the median effect sizes
df_sad_nomask_plot <- aggregate(df_permutation_sad_nomask_2$estimate, list(df_permutation_sad_nomask_2$specificationN), median)

#create dataset with 2.5th quantile
df_sad_nomask_plot_2.5 <- aggregate(df_permutation_sad_nomask_2$estimate, list(df_permutation_sad_nomask_2$specificationN), FUN = function(x) quantile(x, c(.025)))

df_sad_nomask_plot_97.5 <- aggregate(df_permutation_sad_nomask_2$estimate, list(df_permutation_sad_nomask_2$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df_sad_nomask_plot$observedETA <- df_sad_nomask_mult$estimate
df_sad_nomask_plot$q0.25 <- df_sad_nomask_plot_2.5$x
df_sad_nomask_plot$q97.5 <- df_sad_nomask_plot_97.5$x
df_sad_nomask_plot_ordered <- df_sad_nomask_plot[order(df_sad_nomask_plot$observedETA),]
df_sad_nomask_plot_ordered$order <- seq.int(nrow(df_sad_nomask_plot_ordered))

colors <- c("Median Observed" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot6 <- ggplot(data = df_sad_nomask_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Median Observed")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(-1, 1) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification Sadness Unmasked") +
  labs(x = "Specification",
       y = "Cohen´s D",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))




###Visualisation of P-Values###
##2*2 Angry##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df_angry_nomask_mult_x <- df_angry_nomask_mult[,1:11]
df_permutation_angry_nomask_x <- df_permutation_angry_nomask_2[,3:13]

#assign a new type
df_angry_nomask_mult_x$Type <- 1 #observed
df_permutation_angry_nomask_x$Type <- 2 #permutation

df_angry_nomask_pval_plot <- as.data.frame(rbind(df_angry_nomask_mult_x, df_permutation_angry_nomask_x))



ggplot(data=df_angry_nomask_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))

##2*2 Sad##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df_sad_nomask_mult_x <- df_sad_nomask_mult[,1:11]
df_permutation_sad_nomask_x <- df_permutation_sad_nomask_2[,3:13]

#assign a new type
df_sad_nomask_mult_x$Type <- 1 #observed
df_permutation_sad_nomask_x$Type <- 2 #permutation


df_sad_nomask_pval_plot <- as.data.frame(rbind(df_sad_nomask_mult_x, df_permutation_sad_nomask_x))



ggplot(data=df_sad_nomask_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))



#plot of p-value patterns
df_multiverse_plot <- df_angry_nomask_mult





df_multiverse_plot$significance_anger <- ifelse(df_multiverse_plot$p.value < 0.05, 1, 0)


#preparing the dataset for plotting
df_multiverse_plot$min[is.na(df_multiverse_plot$min)] <- 0
df_multiverse_plot$DispersionMeasure[is.na(df_multiverse_plot$DispersionMeasure)] <- 0

df_multiverse_plot$DispersionMeasure <- as.factor(df_multiverse_plot$DispersionMeasure)

df_multiverse_plot$DispersionMeasure <- revalue(df_multiverse_plot$DispersionMeasure, c("0" = "MAD: No limits", "1" = "MAD: 1", "1.5" = "MAD: 1.5", "2" = "MAD: 2", "2.5" = "MAD: 2.5", "3" = "MAD: 3"))



angry_unmasked_plot <- df_multiverse_plot %>% ggplot(aes(x=transformation, y = min, color = as.factor(significance_anger))) +
  geom_point(size = 3) +
  scale_color_colorblind(name = "Significance", labels = c(`0` = "p > .05", `1` = "p < .05", `2`= "p < .05 (both 2x2 and 2x2x2)")) +
  facet_grid(df_multiverse_plot$DispersionMeasure) +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank())
angry_unmasked_plot

