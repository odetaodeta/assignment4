####Visualing basic latency data####
#setup
#packages
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez, afex, gridExtra, emmeans)


citation("gridExtra")
packageVersion("gridExtra")


#load functions, must be in same folder
source("trimmingFixedFunctions.R")
source("transformationFunctions.R")
source("trimmingDataFunctions.R")
source("convenienceFunctions.R")
source("multiverseAnalyses.R")
source("ANOVAfreqMultiverse.R")

#load general data
dataStudy1<- read.csv(here::here("Study1_data_file_155.csv"))



dataStudy1$Emotion <- as.factor(dataStudy1$Emotion)
dataStudy1$Emotion <- revalue(dataStudy1$Emotion, c("1" = "Sadness", "2" = "Anger"))
dataStudy1$ModelGender <- as.factor(dataStudy1$ModelGender)
dataStudy1$ModelGender <- revalue(dataStudy1$ModelGender, c("1" = "Male", "2" = "Female"))
dataStudy1$MaskStatus <- as.factor(dataStudy1$MaskStatus)
dataStudy1$MaskStatus <- revalue(dataStudy1$MaskStatus, c("1" = "Mask", "2" = "NoMask"))


#we fit a basic anova to the raw data
#we are not interested in the results, we just want to use the resulting object for plotting
anova <- aov_ez("subject", "latency", dataStudy1, within = c("Emotion", "ModelGender", "MaskStatus"))
#shows results
anova


#make plot
plot_latency <- afex_plot(anova, x = "MaskStatus", trace = "ModelGender", panel = "Emotion", error = "within", mapping = c("color", "fill", "shape"), data_geom = geom_violin, data_arg = list(width = 0.4), point_arg = list(size = 1.5), line_arg = list(size = 1)) + theme_bw() + 
    theme(axis.title.x=element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA)) + scale_fill_manual(values=c("#E69F00", "#56B4E9")) + ggtitle("Visualisation Latency")
plot_latency

latency_summary <- aggregate(dataStudy1$latency, list(dataStudy1$Emotion, dataStudy1$ModelGender, dataStudy1$MaskStatus), mean)
latency_summary_sd <- aggregate(dataStudy1$latency, list(dataStudy1$Emotion, dataStudy1$ModelGender, dataStudy1$MaskStatus), sd)

latency_summary$Emotion <- as.factor(latency_summary$Group.1)
latency_summary$ModelGender <- as.factor(latency_summary$Group.2)
latency_summary$MaskStatus <- as.factor(latency_summary$Group.3)

latency_summary_sd$Emotion <- as.factor(latency_summary_sd$Group.1)
latency_summary_sd$ModelGender <- as.factor(latency_summary_sd$Group.2)
latency_summary_sd$MaskStatus <- as.factor(latency_summary_sd$Group.3)



####Combine Plots for Figure 1#####
#Note: You need to load Study 1 Accuracy Analyses.R for this to execute.
dev.copy(png, "OverviewPlotData.png")
plot <- grid.arrange(plot_latency, plot_accuracy)


dev.off()
