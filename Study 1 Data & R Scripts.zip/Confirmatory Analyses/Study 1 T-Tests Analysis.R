#setup
#packages
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez, gridExtra)

#load functions, must be in same folder
source("trimmingFixedFunctions.R")
source("transformationFunctions.R")
source("trimmingDataFunctions.R")
source("convenienceFunctions.R")
source("multiverseAnalyses.R")
source("ANOVAfreqMultiverse.R")

#load general data
dataStudy1<- read.csv(here::here("Study1_data_file_155.csv"))

#set up number of permutation. Must be equal to actual number of permutations
permutation <- 1:500

#####Follow-up Multiverse T-test######

####2*2 Compare Male Angry with Female Angry####
#load dataset
df_angry_2x2 <- subset(dataStudy1, dataStudy1$Emotion == "2")
df_permutation_angry_2x2 <- read.csv(here::here("permutation_angry_2x2.csv"))


#run multiverse analysis
df_angry_2x2_mult <- multiverse.t.test(df_angry_2x2, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "ModelGender", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)



#create a copy of the dataset
df_permutation_angry_2x2_2 <- df_permutation_angry_2x2


###Effect Size Calculations###
#get median effect sizes of observed effect
median(df_angry_2x2_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_angry_2x2_2_perm_median <- aggregate(df_permutation_angry_2x2_2$estimate, list(df_permutation_angry_2x2_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_angry_2x2_2_perm_median$x) >= abs(median(df_angry_2x2_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#p = <.002
#0/500 iterations have a median effect size as extreme or more extreme. This does not take 

###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2_angry_p_val <- multiverse.prop(df_angry_2x2_mult, type = "frequentist", df_angry_2x2_mult$p.value))
(df2x2_angry_pval_number <- df2x2_angry_p_val * nrow(df_angry_2x2_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_angry_2x2_2$numbersignificant <- ifelse(df_permutation_angry_2x2_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2_angry_pval_perm <- aggregate(df_permutation_angry_2x2_2$numbersignificant, list(df_permutation_angry_2x2_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2_angry_pval_perm_prop <- ifelse(df2x2_angry_pval_perm$x >= df2x2_angry_pval_number, 1, 0)
sum(df2x2_angry_pval_perm_prop)
#2/500 iterations have the same or a higher number of significant specifications
# p = .004

#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.
#male = 1 , female = 2 -> we predict lower RT for male faces, hence a negative effect
#however, observed data finds positive effect.

#calculate proportion for observed data
df_2x2_anger_observed_sign <- subset(df_angry_2x2_mult, df_angry_2x2_mult$estimate < 0)
(df2x2_angry_sign_val <- multiverse.prop(df_2x2_anger_observed_sign, type = "frequentist", df_2x2_anger_observed_sign$p.value))
df2x2_angry_sign_pval_number <- (df2x2_angry_sign_val * nrow(df_2x2_anger_observed_sign))


#and for permutated data
df_2x2_anger_sign <- subset(df_permutation_angry_2x2_2, df_permutation_angry_2x2_2$estimate < 0)
#create summarised dataframe with one row by iteration
(df2x2_anger_sign_pval <- aggregate(df_2x2_anger_sign$numbersignificant, list(df_2x2_anger_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df2x2_anger_sign_prop <- ifelse(df2x2_anger_sign_pval$x >= df2x2_angry_sign_pval_number , 1, 0)
sum(df2x2_anger_sign_prop) 
sum(df2x2_anger_sign_prop) / length(permutation)
#1/500 have an effect in the expected direction and the same or higher share of significant specifications
# p = 002


####2*2 Compare Male Sad with Female Sad####
df_sad_2x2 <- subset(dataStudy1, dataStudy1$Emotion == "1")
df_permutation_sad_2x2 <- read.csv(here::here("permutation_sad_2x2.csv"))



#run multiverse analysis
df_sad_2x2_mult <- multiverse.t.test(df_sad_2x2, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "ModelGender", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)

#create a copy of the dataset
df_permutation_sad_2x2_2 <- df_permutation_sad_2x2


###Effect Size Calculations###
#get median effect sizes of observed effect
median(df_sad_2x2_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_sad_2x2_2_perm_median <- aggregate(df_permutation_sad_2x2_2$estimate, list(df_permutation_sad_2x2_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_sad_2x2_2_perm_median$x) >= abs(median(df_sad_2x2_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#392/500 iterations have a median effect size as or more extreme
#p < .784


###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2_sad_p_val <- multiverse.prop(df_sad_2x2_mult, type = "frequentist", df_sad_2x2_mult$p.value))
(df2x2_sad_pval_number <- df2x2_sad_p_val * nrow(df_sad_2x2_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_sad_2x2_2$numbersignificant <- ifelse(df_permutation_sad_2x2_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2_sad_pval_perm <- aggregate(df_permutation_sad_2x2_2$numbersignificant, list(df_permutation_sad_2x2_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2_sad_pval_perm_prop <- ifelse(df2x2_sad_pval_perm$x >= df2x2_sad_pval_number, 1, 0)
sum(df2x2_sad_pval_perm_prop)

sum(df2x2_sad_pval_perm_prop) / length(permutation)
#500/500 have the same or a higher number of significant specifications
# p = 1

#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.
#male = 1 , female = 2 -> we predict lower RT for female faces, hence a positive effect
#observed data
df_2x2_sadness_observed_sign <- subset(df_sad_2x2_mult, df_sad_2x2_mult$estimate > 0)
(df2x2_sad_sign_val <- multiverse.prop(df_2x2_sadness_observed_sign, type = "frequentist", df_2x2_sadness_observed_sign$p.value))
df2x2_sad_sign_pval_number <- (df2x2_sad_sign_val * nrow(df_2x2_sadness_observed_sign))



#removes all specifications which do not have the hypothised direction
df_2x2_sadness_sign <- subset(df_permutation_sad_2x2_2, df_permutation_sad_2x2_2$estimate > 0)
#create summarised dataframe with one row by iteration

(df2x2_sadness_sign_pval <- aggregate(df_2x2_sadness_sign$numbersignificant, list(df_2x2_sadness_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df2x2_sadness_sign_prop <- ifelse(df2x2_sadness_sign_pval$x >= df2x2_sad_sign_pval_number, 1, 0)
sum(df2x2_sadness_sign_prop)
sum(df2x2_sadness_sign_prop) / length(permutation)
#416/500have the or a higher number of significant specifications with effect sizes in the expected direction

####2*2*2 Angry####
df_angry_2x2x2 <- df_angry_2x2[,c(5,8:11)]
df_permutation_angry_2x2x2 <- read.csv(here::here("permutation_angry_2x2x2.csv"))

#run multiverse
#does a t-test on difference scores
df_angry_2x2x2_mult <- multiverse.t.test2(df_angry_2x2x2, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "ModelGender", conditionvariable2 = "MaskStatus", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)


#create a copy of the dataset
df_permutation_angry_2x2x2_2 <- df_permutation_angry_2x2x2



###Effect Size Calculations###
#get median effect sizes of observed effect
median(df_angry_2x2x2_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_angry_2x2x2_2_perm_median <- aggregate(df_permutation_angry_2x2x2_2$estimate, list(df_permutation_angry_2x2x2_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()


(median_proportion <- ifelse(abs(df_permutation_angry_2x2x2_2_perm_median$x) >= abs(median(df_angry_2x2x2_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#1/500 iterations have the a median effect size as or more extreme
#p = .002


###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2x2_angry_p_val <- multiverse.prop(df_angry_2x2x2_mult, type = "frequentist", df_angry_2x2x2_mult$p.value))
(df2x2x2_angry_p_val_number <- df2x2x2_angry_p_val * nrow(df_angry_2x2x2_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_angry_2x2x2_2$numbersignificant <- ifelse(df_permutation_angry_2x2x2_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2x2_angry_pval_perm <- aggregate(df_permutation_angry_2x2x2_2$numbersignificant, list(df_permutation_angry_2x2x2_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2x2_angry_pval_perm_prop <- ifelse(df2x2x2_angry_pval_perm$x >= df2x2x2_angry_p_val_number, 1, 0)
sum(df2x2x2_angry_pval_perm_prop)
sum(df2x2x2_angry_pval_perm_prop) / length(permutation)
#11/500 iterations have the same or a higher share of significant specifications

#calculate number of permutations with same or equal number of significant results with an effect in the observed direction.
df_2x2x2_anger_observed_sign <- subset(df_angry_2x2x2_mult, df_angry_2x2x2_mult$estimate > 0) # < for expected direction gives 0 as result.
(df2x2x2_anger_sign_val <- multiverse.prop(df_2x2x2_anger_observed_sign, type = "frequentist", df_2x2x2_anger_observed_sign$p.value))
(df2x2x2_anger_sign_pval_number <- df2x2x2_anger_sign_val * nrow(df_2x2x2_anger_observed_sign))

#df_2x2x2_anger_sign <- subset(df_permutation_angry_2x2x2_2, df_permutation_angry_2x2x2_2$estimate < 0) #if you want to calculate for the expected direction

#observed direction
df_2x2x2_anger_sign <- subset(df_permutation_angry_2x2x2_2, df_permutation_angry_2x2x2_2$estimate > 0)
#create summarised dataframe with one row by iteration

(df2x2x2_anger_sign_pval <- aggregate(df_2x2x2_anger_sign$numbersignificant, list(df_2x2x2_anger_sign$count), sum))

#proportion of iterations with the same number or higher number of significant specifications in the observed direction
df2x2x2_anger_sign_prop <- ifelse(df2x2x2_anger_sign_pval$x >= df2x2x2_anger_sign_pval_number, 1, 0)

#df2x2x2_anger_sign_prop <- ifelse(df2x2x2_anger_sign_pval$x >= 0, 1, 0) #for the expected direction.

sum(df2x2x2_anger_sign_prop)

sum(df2x2x2_anger_sign_prop) / length(permutation)
#1/500, p =  .006


####2*2*2 Sad####
df_sad_2x2x2 <- df_sad_2x2[,c(5,8:11)]


df_permutation_sad_2x2x2 <- read.csv(here::here("permutation_sad_2x2x2.csv"))


#run multiverse
df_sad_2x2x2_mult <- multiverse.t.test2(df_sad_2x2x2, valuevariable = "latency", idvariable = "pp_num", conditionvariable = "ModelGender", conditionvariable2 = "MaskStatus", TransformationTypes = c("raw", "log", "normal"),  FixedTrimmingTypes = c("min", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad"), TestTypes = c("freq.t.test"),  data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)



#create a copy of the dataset
df_permutation_sad_2x2x2_2 <- df_permutation_sad_2x2x2



###Effect Size Calculations###
#get median effect sizes of observed effect
median(df_sad_2x2x2_mult$estimate)


#calculate median effect size for each iteration of the permutation
(df_permutation_sad_2x2x2_2_perm_median <- aggregate(df_permutation_sad_2x2x2_2$estimate, list(df_permutation_sad_2x2x2_2$count), median))

#calculate proportion of medians >= than median in observed data
#Cohen´s d can be negative and positive, hence the abs()
(median_proportion <- ifelse(abs(df_permutation_sad_2x2x2_2_perm_median$x) >= abs(median(df_sad_2x2x2_mult$estimate)), 1, 0))

(sum_median_proportion <- sum(median_proportion))


#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#215/500
#.43

###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2x2_sad_p_val <- multiverse.prop(df_sad_2x2x2_mult, type = "frequentist", df_sad_2x2x2_mult$p.value))
(df2x2x2_sad_p_val_number <- df2x2x2_sad_p_val * nrow(df_sad_2x2x2_mult))

#permutated data
#calculate number of significant p-values by iteration
df_permutation_sad_2x2x2_2$numbersignificant <- ifelse(df_permutation_sad_2x2x2_2$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2x2_sad_pval_perm <- aggregate(df_permutation_sad_2x2x2_2$numbersignificant, list(df_permutation_sad_2x2x2_2$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2x2_sad_pval_perm_prop <- ifelse(df2x2x2_sad_pval_perm$x >= df2x2x2_sad_p_val_number, 1, 0)
sum(df2x2x2_sad_pval_perm_prop)

sum(df2x2x2_sad_pval_perm_prop) / length(permutation)
# p = 1


#calculate number of permutations with same or equal number of significant results with an effect in the predicted direction.

df_2x2x2_sadness_observed_sign <- subset(df_sad_2x2x2_mult, df_sad_2x2x2_mult$estimate < 0) 
(df2x2x2_sadness_sign_val <- multiverse.prop(df_2x2x2_sadness_observed_sign, type = "frequentist", df_2x2x2_sadness_observed_sign$p.value))
df2x2x2_sadness_sign_pval_number <- (df2x2x2_sadness_sign_val * nrow(df_2x2x2_sadness_observed_sign))
df2x2x2_sadness_sign_pval_number 


df_2x2x2_sad_sign <- subset(df_permutation_sad_2x2x2_2, df_permutation_sad_2x2x2_2$estimate < 0)

#create summarised dataframe with one row by iteration
(df2x2x2_sad_sign_pval <- aggregate(df_2x2x2_sad_sign$numbersignificant, list(df_2x2x2_sad_sign$count), sum))
#proportion of iterations with the same number or higher number of significant specifications in the hypothesized direction
df2x2x2_sad_sign_prop <- ifelse(df2x2x2_sad_sign_pval$x >= df2x2x2_sadness_sign_pval_number , 1, 0)
#df2x2x2_sad_sign_prop <- ifelse(df2x2x2_sad_sign_pval$x >= 0, 1, 0)
sum(df2x2x2_sad_sign_prop)
sum(df2x2x2_sad_sign_prop) / length(permutation)
#405/500 p = .81



###Visualisation of Effect Sizes Multiverse T-Tests####
##2*2 Angry##
df_angry_2x2_mult$specificationN <- seq.int(nrow(df_angry_2x2_mult))
df_permutation_angry_2x2_2$specificationN <- rep(1:126, times = 500) #this number should be 500

#create a dataset with the median effect sizes
df2x2_angry_plot <- aggregate(df_permutation_angry_2x2_2$estimate, list(df_permutation_angry_2x2_2$specificationN), median)

#create dataset with 2.5th quantile
df2x2_angry_plot_2.5 <- aggregate(df_permutation_angry_2x2_2$estimate, list(df_permutation_angry_2x2_2$specificationN), FUN = function(x) quantile(x, c(.025)))

df2x2_angry_plot_97.5 <- aggregate(df_permutation_angry_2x2_2$estimate, list(df_permutation_angry_2x2_2$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df2x2_angry_plot$observedETA <- df_angry_2x2_mult$estimate
df2x2_angry_plot$q0.25 <- df2x2_angry_plot_2.5$x
df2x2_angry_plot$q97.5 <- df2x2_angry_plot_97.5$x
df2x2_angry_plot_ordered <- df2x2_angry_plot[order(df2x2_angry_plot$observedETA),]
df2x2_angry_plot_ordered$order <- seq.int(nrow(df2x2_angry_plot_ordered))

colors <- c("Observed Data" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot1 <- ggplot(data = df2x2_angry_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Observed Data")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(-1, 0.35) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification 2x2 Anger") +
  labs(x = "Specification",
       y = "Cohen´s D",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))

##2*2 Sad##
df_sad_2x2_mult$specificationN <- seq.int(nrow(df_sad_2x2_mult))
df_permutation_sad_2x2_2$specificationN <- rep(1:126, times = 500)

#create a dataset with the median effect sizes
df2x2_sad_plot <- aggregate(df_permutation_sad_2x2_2$estimate, list(df_permutation_sad_2x2_2$specificationN), median)

#create dataset with 2.5th quantile
df2x2_sad_plot_2.5 <- aggregate(df_permutation_sad_2x2_2$estimate, list(df_permutation_sad_2x2_2$specificationN), FUN = function(x) quantile(x, c(.025)))

df2x2_sad_plot_97.5 <- aggregate(df_permutation_sad_2x2_2$estimate, list(df_permutation_sad_2x2_2$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df2x2_sad_plot$observedETA <- df_sad_2x2_mult$estimate
df2x2_sad_plot$q0.25 <- df2x2_sad_plot_2.5$x
df2x2_sad_plot$q97.5 <- df2x2_sad_plot_97.5$x
df2x2_sad_plot_ordered <- df2x2_sad_plot[order(df2x2_sad_plot$observedETA),]
df2x2_sad_plot_ordered$order <- seq.int(nrow(df2x2_sad_plot_ordered))

colors <- c("Observed Data" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot2 <- ggplot(data = df2x2_sad_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Observed Data")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(-0.5, 1) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification 2x2 Sadness") +
  labs(x = "Specification",
       y = "Cohen´s D",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))


##2*2*2 Angry##
df_angry_2x2x2_mult$specificationN <- seq.int(nrow(df_angry_2x2x2_mult))
df_permutation_angry_2x2x2_2$specificationN <- rep(1:126, times = 500)

#create a dataset with the median effect sizes
df2x2x2_angry_plot <- aggregate(df_permutation_angry_2x2x2_2$estimate, list(df_permutation_angry_2x2x2_2$specificationN), median)

#create dataset with 2.5th quantile
df2x2x2_angry_plot_2.5 <- aggregate(df_permutation_angry_2x2x2_2$estimate, list(df_permutation_angry_2x2x2_2$specificationN), FUN = function(x) quantile(x, c(.025)))

df2x2x2_angry_plot_97.5 <- aggregate(df_permutation_angry_2x2x2_2$estimate, list(df_permutation_angry_2x2x2_2$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df2x2x2_angry_plot$observedETA <- df_angry_2x2x2_mult$estimate
df2x2x2_angry_plot$q0.25 <- df2x2x2_angry_plot_2.5$x
df2x2x2_angry_plot$q97.5 <- df2x2x2_angry_plot_97.5$x
df2x2x2_angry_plot_ordered <- df2x2x2_angry_plot[order(df2x2x2_angry_plot$observedETA),]
df2x2x2_angry_plot_ordered$order <- seq.int(nrow(df2x2x2_angry_plot_ordered))


colors <- c("Observed Data" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot3 <- ggplot(data = df2x2x2_angry_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Observed Data")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(-0.5, 0.5) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification 2x2x2 Anger") +
  labs(x = "Specification",
       y = "Cohen´s D",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))



##2*2*2 Sad##
df_sad_2x2x2_mult$specificationN <- seq.int(nrow(df_sad_2x2x2_mult))
df_permutation_sad_2x2x2_2$specificationN <- rep(1:126, times = 500)

#create a dataset with the median effect sizes
df2x2x2_sad_plot <- aggregate(df_permutation_sad_2x2x2_2$estimate, list(df_permutation_sad_2x2x2_2$specificationN), median)

#create dataset with 2.5th quantile
df2x2x2_sad_plot_2.5 <- aggregate(df_permutation_sad_2x2x2_2$estimate, list(df_permutation_sad_2x2x2_2$specificationN), FUN = function(x) quantile(x, c(.025)))

df2x2x2_sad_plot_97.5 <- aggregate(df_permutation_sad_2x2x2_2$estimate, list(df_permutation_sad_2x2x2_2$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df2x2x2_sad_plot$observedETA <- df_sad_2x2x2_mult$estimate
df2x2x2_sad_plot$q0.25 <- df2x2x2_sad_plot_2.5$x
df2x2x2_sad_plot$q97.5 <- df2x2x2_sad_plot_97.5$x
df2x2x2_sad_plot_ordered <- df2x2x2_sad_plot[order(df2x2x2_sad_plot$observedETA),]
df2x2x2_sad_plot_ordered$order <- seq.int(nrow(df2x2x2_sad_plot_ordered))

colors <- c("Observed Data" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot4 <- ggplot(data = df2x2x2_sad_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Observed Data")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(-0.5, 0.5) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification 2x2x2 Sadness") +
  labs(x = "Specification",
       y = "Cohen´s D",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))



##combine plots for figure##
##also execute the Study 1 Unmasked Subset T-Tests.R and Study 1 ANOVA Analysis.R for this.
plot_combined <- grid.arrange(plot7, plot8, plot1, plot2, plot3, plot4, plot5, plot6, ncol = 2)
plot_combined
ggsave("plot_combined_t.tests.png", plot_combined, width = 30, height = 30, units = "cm")

#####Visualisation of P-values#####
##2*2 Angry##

#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df_angry_2x2_mult_x <- df_angry_2x2_mult[,1:11]
df_permutation_angry_2x2_x <- df_permutation_angry_2x2_2[,3:13]

#assign a new type
df_angry_2x2_mult_x$Type <- 1 #observed
df_permutation_angry_2x2_x$Type <- 2 #permutation

df_angry_2x2_pval_plot <- as.data.frame(rbind(df_angry_2x2_mult_x, df_permutation_angry_2x2_x))



ggplot(data=df_angry_2x2_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))

##2*2 Sad##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df_sad_2x2_mult_x <- df_sad_2x2_mult[,1:11]
df_permutation_sad_2x2_x <- df_permutation_sad_2x2_2[,3:13]

#assign a new type
df_sad_2x2_mult_x$Type <- 1 #observed
df_permutation_sad_2x2_x$Type <- 2 #permutation

df_sad_2x2_pval_plot <- as.data.frame(rbind(df_sad_2x2_mult_x, df_permutation_sad_2x2_x))

str(df_sad_2x2_pval_plot)
max(df_sad_2x2_pval_plot$p.value)

ggplot(data=df_sad_2x2_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))


##2*2*2 Angry##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df_angry_2x2x2_mult_x <- df_angry_2x2x2_mult[,1:11]
df_permutation_angry_2x2x2_x <- df_permutation_angry_2x2x2_2[,3:13]

#assign a new type
df_angry_2x2x2_mult_x$Type <- 1 #observed
df_permutation_angry_2x2x2_x$Type <- 2 #permutation

df_angry_2x2x2_pval_plot <- as.data.frame(rbind(df_angry_2x2x2_mult_x, df_permutation_angry_2x2x2_x))



ggplot(data=df_angry_2x2x2_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))

##2*2*2 Sad##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df_sad_2x2x2_mult_x <- df_sad_2x2x2_mult[,1:11]
df_permutation_sad_2x2x2_x <- df_permutation_sad_2x2x2_2[,3:13]

#assign a new type
df_sad_2x2x2_mult_x$Type <- 1 #observed
df_permutation_sad_2x2x2_x$Type <- 2 #permutation

df_sad_2x2x2_pval_plot <- as.data.frame(rbind(df_sad_2x2x2_mult_x, df_permutation_sad_2x2x2_x))



ggplot(data=df_sad_2x2x2_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))




####plotting significance pattern#####
df_multiverse_plot <- df_sad_2x2x2_mult



df_multiverse_plot$significance2x2 <- ifelse(df_multiverse_plot$p.value < 0.05, 1, 0)

#this is just to showcase what the plot could like.


#preparing the dataset for plotting
df_multiverse_plot$min[is.na(df_multiverse_plot$min)] <- 0
df_multiverse_plot$DispersionMeasure[is.na(df_multiverse_plot$DispersionMeasure)] <- 0

df_multiverse_plot$DispersionMeasure <- as.factor(df_multiverse_plot$DispersionMeasure)

df_multiverse_plot$DispersionMeasure <- revalue(df_multiverse_plot$DispersionMeasure, c("0" = "MAD: No limits", "1" = "MAD: 1", "1.5" = "MAD: 1.5", "2" = "MAD: 2", "2.5" = "MAD: 2.5", "3" = "MAD: 3"))



sad_2x2x2_plot <- df_multiverse_plot %>% ggplot(aes(x=transformation, y = min, color = as.factor(significance2x2))) +
  geom_point(size = 3) +
  scale_color_colorblind(name = "Significance", labels = c(`0` = "p > .05", `1` = "p < .05", `2`= "p < .05 (both 2x2 and 2x2x2)")) +
  facet_grid(df_multiverse_plot$DispersionMeasure) +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank())

sad_2x2x2_plot 





