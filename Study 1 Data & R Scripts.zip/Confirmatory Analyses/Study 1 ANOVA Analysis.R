#setup
if (!require("pacman")) install.packages("pacman")
pacman::p_load(MASS, tidyverse, plyr, ggplot2, dplyr, ggpubr,rstatix, here, reshape2, gtools, ggthemes, effsize, DescTools, rqPen, data.table, ez)

#load functions, must be in same folder
source("trimmingFixedFunctions.R")
source("transformationFunctions.R")
source("trimmingDataFunctions.R")
source("convenienceFunctions.R")
source("multiverseAnalyses.R")
source("ANOVAfreqMultiverse.R")


#load dataframes
df2x2_perm <- read.csv(here::here("anova_2x2_permutations.csv"))
df2x2x2_perm <- read.csv(here::here("anova_2x2x2_permutations.csv"))
dataStudy1 <- read.csv(here::here("Study1_data_file_155.csv"))




#Note: the t.statistic is actually the F.value, I just had to rename it to make the permutation loop fit.
df2x2_perm <- df2x2_perm  %>% 
  dplyr::rename(
    F.value = t.value,
   partialetasquared = estimate
  )
df2x2x2_perm <- df2x2x2_perm  %>% 
  dplyr::rename(
    F.value = t.value,
    partialetasquared = estimate
  )


#Permutations are done elsewhere, but we need the variable to calculate proportions of permutations.
permutation <- 1:500

######multiverse analysis########

###ANOVA###


#do multiverse analysis of observed data
df_mult_sim <- multiverse.freq.anova(dataframe = dataStudy1, valuevariable = "latency", idvariable = "pp_num", within1 = "Emotion", within2 = "MaskStatus", within3 = "ModelGender", between1 = NA, TransformationTypes = c("raw","log", "normal"),  FixedTrimmingTypes = c("nofixedtrimming", "min"), DataTrimmingTypes = c("notrimming", "mad"), data.lower = 1, data.upper = 3, data.step =0.5, fixed.min.lower = 0.05, fixed.min.upper = 0.3, fixed.min.step = 0.05, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE)


df_mult_sim  <- df_mult_sim   %>% 
  dplyr::rename(
    F.value = t.value,
    partialetasquared = estimate
  )





#seperate dataframe by effects of interest

#####2*2 Emotion * Gender Interaction#####
#within1 * within3 here of observed data
df2x2 <- subset(df_mult_sim, df_mult_sim$model == "within1:within3")


###Effect Size Calculations###
#get median effect sizes of observed effect
median(df2x2$partialetasquared)


#calculate median effect size for each iteration of the permutation
(df2x2_perm_median <- aggregate(df2x2_perm$partialetasquared, list(df2x2_perm$count), median))


#calculate proportion of medians >= than median in observed data
(median_proportion <- ifelse(df2x2_perm_median$x >= median(df2x2$partialetasquared), 1, 0))
(sum_median_proportion <- sum(median_proportion))


#calculate p-value = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion / length(permutation)
#interpretation: 0/500 of an median effect size as or more extreme than the observed data. p < .002

###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2_pval <- multiverse.prop(df2x2, type = "frequentist", df2x2$p.value))
(df2x2_pval_number <- df2x2_pval * nrow(df2x2))

#permutated data
#calculate number of significant p-values by iteration
df2x2_perm$numbersignificant <- ifelse(df2x2_perm$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2_pval_perm <- aggregate(df2x2_perm$numbersignificant, list(df2x2_perm$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2_pval_perm_prop <- ifelse(df2x2_pval_perm$x >= df2x2_pval_number, 1, 0)
sum(df2x2_pval_perm_prop)
sum(df2x2_pval_perm_prop) / length(permutation)

#interpretation: 1/500 iterations have the same or a higher number of significant specifications

#####2*2*2 Gender*Emotion*Mask Interaction#####

#within1 * within2 * within3 here of observed data
df2x2x2 <- subset(df_mult_sim, df_mult_sim$model == "within1:within2:within3")


###Effect Size Calculations###
#get median effect sizes of observed effect
median(df2x2x2$partialetasquared)


#calculate median effect size for each iteration of the permutation
(df2x2x2_perm_median <- aggregate(df2x2x2_perm$partialetasquared, list(df2x2x2_perm$count), median))

#calculate proportion of medians >= than median in observed data
(median_proportion_2x2x2 <- ifelse(df2x2x2_perm_median$x >= median(df2x2x2$partialetasquared), 1, 0))

(sum_median_proportion_2x2x2 <- sum(median_proportion_2x2x2))

#interpretation: 3/500 iterations have a median effect size as extreme or more extreme

#calculate p-vale = % shuffled samples with results as or more extreme compared to observed
#Quote from Simonsohn: #"Among  the  500  shuffled  samples,  425  have  at  least  37 significant  effects,  leading  to  a p-value for this joint test #of p=425/500 = .85. See Table 2"

sum_median_proportion_2x2x2 / length(permutation)
# p = .006

###P-Value Calculations###
#calculate proportion of significant p-values.
#observed data
(df2x2x2_pval <- multiverse.prop(df2x2x2, type = "frequentist", df2x2x2$p.value))
(df2x2x2_pval_number <- df2x2x2_pval * nrow(df2x2x2))

#permutated data
#calculate number of significant p-values by iteration
df2x2x2_perm$numbersignificant <- ifelse(df2x2x2_perm$p.value < 0.05, 1, 0)


#create summarised dataframe with one row by iteration
(df2x2x2_pval_perm <- aggregate(df2x2x2_perm$numbersignificant, list(df2x2x2_perm$count), sum))

#calculate number of permutations with same or equal number of significant results
df2x2x2_pval_perm_prop <- ifelse(df2x2x2_pval_perm$x >= df2x2x2_pval_number, 1, 0)
sum(df2x2x2_pval_perm_prop)
sum(df2x2x2_pval_perm_prop) / length(permutation)
#interpretation: 13/ 500 iterations have the same or a higher number of significant specifications


#####Visualisation of Effect Sizes#####

##2*2##

#create one variable that just counts the specifications. it can be nrow, because selecting only one model removes all double specifications
df2x2$specificationN <- seq.int(nrow(df2x2))
df2x2_perm$specificationN <- rep(1:126, times = 100)

#create a dataset with the median effect sizes
df2x2_plot <- aggregate(df2x2_perm$partialetasquared, list(df2x2_perm$specificationN), median)

#create dataset with 2.5th quantile
df2x2_plot_2.5 <- aggregate(df2x2_perm$partialetasquared, list(df2x2_perm$specificationN), FUN = function(x) quantile(x, c(.025)))

df2x2_plot_97.5 <- aggregate(df2x2_perm$partialetasquared, list(df2x2_perm$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df2x2_plot$observedETA <- df2x2$partialetasquared
df2x2_plot$q0.25 <- df2x2_plot_2.5$x
df2x2_plot$q97.5 <- df2x2_plot_97.5$x
df2x2_plot_ordered <- df2x2_plot[order(df2x2_plot$observedETA),]
df2x2_plot_ordered$order <- seq.int(nrow(df2x2_plot_ordered))

colors <- c("Median Observed" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot7 <- ggplot(data = df2x2_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Median Observed")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(0,0.2) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification 2x2 ANOVA") +
  labs(x = "Specification (sorted by effect size)",
       y = "Partial Eta Squared",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))



###2*2*2###
#create one variable that just counts the specifications. it can be nrow, because selecting only one model removes all double specifications
df2x2x2$specificationN <- seq.int(nrow(df2x2x2))
df2x2x2_perm$specificationN <- rep(1:126, times = 500)

#create a dataset with the median effect sizes
df2x2x2_plot <- aggregate(df2x2x2_perm$partialetasquared, list(df2x2x2_perm$specificationN), median)

#create dataset with 2.5th quantile
df2x2x2_plot_2.5 <- aggregate(df2x2x2_perm$partialetasquared, list(df2x2x2_perm$specificationN), FUN = function(x) quantile(x, c(.025)))
#97.5th
df2x2x2_plot_97.5 <- aggregate(df2x2x2_perm$partialetasquared, list(df2x2x2_perm$specificationN), FUN = function(x) quantile(x, c(0.975)))

#add data together
df2x2x2_plot$observedETA <- df2x2x2$partialetasquared
df2x2x2_plot$q0.25 <- df2x2x2_plot_2.5$x
df2x2x2_plot$q97.5 <- df2x2x2_plot_97.5$x

df2x2x2_plot_ordered <- df2x2x2_plot[order(df2x2x2_plot$observedETA),]
df2x2x2_plot_ordered$order <- seq.int(nrow(df2x2x2_plot_ordered))

colors <- c("Median Observed" = "red", "Median Permutation" = "black", "2.5th/97.5th Percentile" = "blue")

plot8 <- ggplot(data = df2x2x2_plot_ordered, aes(x = order)) +
  geom_line(aes(y = observedETA, color = "Median Observed")) +
  geom_line(aes(y = x, color = "Median Permutation"), linetype = 2) +
  geom_line(aes(y = q0.25, color = "2.5th/97.5th Percentile"),  linetype = 3)  +
  geom_line(aes(y = q97.5, color = "2.5th/97.5th Percentile"), linetype = 3) +
  ylim(0,0.1) +  
  xlab("Specification") +
  ylab("Partial Eta Squared") +
  ggtitle("Median Effect Sizes by Specification 2x2x2 ANOVA") +
  labs(x = "Specification",
       y = "Partial Eta Squared",
       color = "Legend") +
  scale_color_manual(values = colors) +
  theme_bw() +
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "transparent",colour = NA),
    plot.background = element_rect(fill = "transparent",colour = NA))



###Visualisation of P-Values ANOVA###
##2*2*2##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df2x2x2_x <- df2x2x2[,1:12]
df2x2x2_perm_x <- df2x2x2_perm[,3:14]

#assign a new type
df2x2x2_x$Type <- 1 #observed
df2x2x2_perm_x$Type <- 2 #permutation


df2x2x2_pval_plot <- as.data.frame(rbind(df2x2x2_x, df2x2x2_perm_x))



ggplot(data=df2x2x2_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))

##2*2##
#Densityplot of Distribution of Observed P-values vs Permutation p-values
#remove last column, so both dataframes have identical column names
df2x2_x <- df2x2[,1:12]
df2x2_perm_x <- df2x2_perm[,3:14]

#assign a new type
df2x2_x$Type <- 1 #observed
df2x2_perm_x$Type <- 2 #permutation

df2x2_pval_plot <- as.data.frame(rbind(df2x2_x, df2x2_perm_x))



ggplot(data=df2x2_pval_plot, aes(x=p.value, group = as.factor(Type), fill = as.factor(Type))) +
  geom_density(alpha = 0.4) +
  geom_density(alpha = 0.4) +
  xlim(0,1) +
  xlab("p-value") + 
  ylab("") + 
  ggtitle("Densityplot of Observed vs Permutated P-values") +
  theme_bw() + 
  geom_vline(xintercept = 0.05, color = "red", linetype = "dashed") + #adds alpha line
  geom_text(x = 0.05, hjust = -0.5, #adds alpha symbol next to line
            y = Inf,
            label = expression(paste(alpha)), 
            color = "red", check_overlap = TRUE,
            vjust = "inward") +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  scale_fill_manual(values = c("chocolate1", "dodgerblue"), name = "Legend", labels = c("1" = "Observed", "2" = "Permutated"))




##### General Visualisation of Multiverse ANOVA Overview######
#load dataframes of the ANOVA. We only do this plot once for the ANOVA to showcase the multiverse
df_multiverse_plot <- df2x2
df_multiverse_plot$p.value2x2x2 <- df2x2x2$p.value

#create fake significance variables to showcase plot
#replace by #actual significance variables. Check again when we have the observed data
df_multiverse_plot$significance2x2 <- ifelse(df_multiverse_plot$p.value < 0.05, 1, 0)
df_multiverse_plot$significance2x2x2 <- ifelse(df_multiverse_plot$p.value2x2x2 < 0.05, 1, 0)

#this is just to showcase what the plot could like.
#df_multiverse_plot$significance2x2 <- rep(c(0,0,1), 42)
#df_multiverse_plot$significance2x2x2 <- rep(c(0,0,0,1,0,1), 21)
df_multiverse_plot$interactionsignificance <- factor(as.numeric(interaction(df_multiverse_plot$significance2x2, df_multiverse_plot$significance2x2x2), levels = seq(1,4)))

#preparing the dataset for plotting
df_multiverse_plot$min[is.na(df_multiverse_plot$min)] <- 0
df_multiverse_plot$DispersionMeasure[is.na(df_multiverse_plot$DispersionMeasure)] <- 0

df_multiverse_plot$DispersionMeasure <- as.factor(df_multiverse_plot$DispersionMeasure)

df_multiverse_plot$DispersionMeasure <- revalue(df_multiverse_plot$DispersionMeasure, c("0" = "MAD: No limits", "1" = "MAD: 1", "1.5" = "MAD: 1.5", "2" = "MAD: 2", "2.5" = "MAD: 2.5", "3" = "MAD: 3"))



anova_plot <- df_multiverse_plot %>% ggplot(aes(x=transformation, y = min, color = as.factor(interactionsignificance))) +
  geom_point(size = 3) +
  scale_color_colorblind(name = "Significance", labels = c(`1` = "p < .05 (2x2)", `2`= "p < .05 (both 2x2 and 2x2x2)")) +
  facet_grid(df_multiverse_plot$DispersionMeasure) +
  theme(axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank())

anova_plot 





####Check results of main ANOVA for the effects not of interest####
df_within1 <- subset(df_mult_sim, df_mult_sim$model == "within1")
df_within2 <- subset(df_mult_sim, df_mult_sim$model == "within2")
df_within3 <- subset(df_mult_sim, df_mult_sim$model == "within3")
df_within1_2 <- subset(df_mult_sim, df_mult_sim$model == "within1:within2")
df_within2_3 <- subset(df_mult_sim, df_mult_sim$model == "within2:within3")

#get median effect sizes of observed effect
median(df_within1$partialetasquared)
median(df_within2$partialetasquared)
median(df_within3$partialetasquared)
median(df_within1_2$partialetasquared)
median(df_within2_3$partialetasquared)


#get proportion of significant results
(df_within1_pval <- multiverse.prop(df_within1, type = "frequentist", df_within1$p.value))
(df_within1_pval_number <- df_within1_pval * nrow(df_within1))


(df_within2_pval <- multiverse.prop(df_within2, type = "frequentist", df_within2$p.value))
(df_within2_pval_number <- df_within2_pval * nrow(df_within2))

(df_within3_pval <- multiverse.prop(df_within3, type = "frequentist", df_within3$p.value))
(df_within3_pval_number <- df_within3_pval * nrow(df_within3))

(df_within1_2_pval <- multiverse.prop(df_within1_2, type = "frequentist", df_within1_2$p.value))
(df_within1_2_pval_number <- df_within1_2_pval * nrow(df_within1_2))

#all except gender by mask have 126/126 pathways significant.
(df_within2_3_pval <- multiverse.prop(df_within2_3, type = "frequentist", df_within2_3$p.value))
(df_within2_3_pval_number <- df_within2_3_pval * nrow(df_within2_3))

#Emotion
aggregate(dataStudy1$latency, list(dataStudy1$Emotion), mean)
#MaskStatus
aggregate(dataStudy1$latency, list(dataStudy1$MaskStatus), mean)
#gender
aggregate(dataStudy1$latency, list(dataStudy1$ModelGender), mean)

#Emotion*Mask
aggregate(dataStudy1$latency, list(dataStudy1$Emotion, dataStudy1$MaskStatus), mean)
#anger mask faster than anger nomask, but minimally, opposite for sadness (and much larger)

aggregate(dataStudy1$latency, list(dataStudy1$MaskStatus, dataStudy1$ModelGender), mean)
#male faster for both, but a signiificant interaction for 42 pathways.

