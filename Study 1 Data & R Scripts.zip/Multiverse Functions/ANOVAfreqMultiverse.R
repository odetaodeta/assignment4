
options(scipen = 999)



multiverse.freq.anova <-  function(dataframe, valuevariable, idvariable, within1, within2 = NA, within3 = NA, between1 = NA, TransformationTypes = c("raw", "inverse", "log", "normal", "square", "squareroot"),  FixedTrimmingTypes = c("min", "max", "minmax", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad", "overall.mean", "subject.mean", "iqr"), data.lower = 2, data.upper = 3, data.step =0.5, fixed.min.lower = 0, fixed.min.upper = 2, fixed.min.step = 0.1, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE){
  ####Setup up variables#####
  
  #takes the number input and turns them into iterable objects
  numberdata <- seq(data.lower, data.upper, data.step) 
  numberfixed.min.s <- seq(fixed.min.lower, fixed.min.upper, fixed.min.step)
  numberfixed.max.s <- seq(fixed.max.lower, fixed.max.upper, fixed.max.step)
  
  #rename columns so that the function works regardless of the input dataset
  data.renamed <- data.rename(dataframe, valuevariable = valuevariable, idvariable = idvariable, within1 = within1, within2 = within2, within3 = within3, between1 = between1, testtype = "anova")
  
  
  newdata <- data.frame() #make an empty dataframe
  
  #make iterable objects of the user decisions regarding which transformations and trimming procedures to aply
  
  
  typestransform <- TransformationTypes
  
  typesdatatrimming <- DataTrimmingTypes
  
  typesfixedtrimming <- FixedTrimmingTypes
  
 
  
  ####Main Loop#####
  for (transformation in typestransform){
    #create a first dataset based on the chosen transformations.
    data.transformed <- transform.master(type = transformation, data.renamed, valuevariable = data.renamed$latency, idvariable = data.renamed$participant)
    
    #set up option to trim based on raw data
    if(RawData == FALSE){
      data.transformed$RTvariable <- data.transformed$transformed
    }
    if(RawData == TRUE){
      data.transformed$RTvariable <- data.transformed$latency
    }#close trim based on raw data setup
    
    #set up data-based trimming loop
    for (datatrimming in typesdatatrimming){
      #set up if clause: No data-based trimming:
      if (datatrimming == "notrimming"){
        data.transformed.datatrimmed <- trim.data.master(type = datatrimming, dataframe = data.transformed, valuevariable = data.transformed$RTvariable, conditionvariable = conditionvariable, idvariable = idvariable)
        n <- NA
        #set up option to trim based on raw data
        if(RawData == FALSE){
          data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$transformed
        }
        if(RawData == TRUE){
          data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$latency
        }#close trim based on raw data setup
        #set up fixed trimming loop
        for (fixedtrimming in typesfixedtrimming){
          #set up else clause if there is fixed trimming
          
          #prepare variables for looping
          if (fixedtrimming == "min"){
            numberfixed.max <- NA
            numberfixed.min <- numberfixed.min.s
          }#close fixed trimming min
          if (fixedtrimming == "max"){
            numberfixed.min <- NA
            numberfixed.max <- numberfixed.max.s
          }#close fixed trimming max
          if (fixedtrimming == "minmax"){
            numberfixed.min <- numberfixed.min.s
            numberfixed.max <- numberfixed.max.s
          }#close fixed trimming minmax
          if (fixedtrimming == "nofixedtrimming"){
            numberfixed.min <- NA
            numberfixed.max <- NA
          }#close nofixedtrimming
          
          for (min in numberfixed.min){
            for (max in numberfixed.max) {
              data.transformed.datatrimmed.fixedtrimmed <- trim.fixed.master(type = fixedtrimming, data.transformed.datatrimmed, data.transformed.datatrimmed$RTvariable, min = min, max = max)  
              
              #assign min and max if no fixed trimming
              if(fixedtrimming == "nofixedtrimming"){
                min <- NA
                max <- NA
              }#close if no fixed trimming assign min&max
              
              
              
              #remove participants that do not have data in both groups
              groups1 <- aggregate(
                within1 ~ participant,
                data.transformed.datatrimmed.fixedtrimmed,
                function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within1)))
              )
              
              compliant_participants1 <- groups1[which(groups1$within1),][["participant"]]
              
              
              #if we only have 1 within factor
              if(is.na(within2) == TRUE){
                data.cleaned <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants1,] 
              }
              
              #if there is a second one, also check for that one              
              if(is.na(within2) == FALSE){
                #if you have 2 within factors
                if(is.na(within3) == TRUE){
                  data.cleaned.prelim <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants1,]
                  
                  groups2 <- aggregate(
                    within2 ~ participant,
                    data.transformed.datatrimmed.fixedtrimmed,
                    function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within2)))
                  )
                  
                  compliant_participants2 <- groups2[which(groups2$within2),][["participant"]]
                  data.cleaned <- data.cleaned.prelim[data.cleaned.prelim$participant %in% compliant_participants2,]
                  
                  
                  
                }
                #if you have 3 within factors
                if(is.na(within3) == FALSE){
                  data.cleaned.prelim <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants1,]
                  
                  groups2 <- aggregate(
                    within2 ~ participant,
                    data.transformed.datatrimmed.fixedtrimmed,
                    function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within2)))
                  )
                  
                  compliant_participants2 <- groups2[which(groups2$within2),][["participant"]]
                  data.cleaned.prelim2 <- data.cleaned.prelim[data.cleaned.prelim$participant %in% compliant_participants2,]
                  
                  
                  
                  #and again for the third factor
                  
                  groups3 <- aggregate(
                    within3 ~ participant,
                    data.transformed.datatrimmed.fixedtrimmed,
                    function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within3)))
                  )
                  
                  compliant_participants3 <- groups3[which(groups3$within3),][["participant"]]
                  data.cleaned <- data.cleaned.prelim2[data.cleaned.prelim2$participant %in% compliant_participants3,]
                  
                  
                  
                  
                  
                  
                  
                  
                }
           
                
              }
              
              
              
              #aggregate data 
              #for 1 within factor
              data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1,data.cleaned$participant, nFactors = 1)
              
              
              if(is.na(within2) == FALSE){
                #for 2 within
                if(is.na(between1) == TRUE){
                  data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 2, conditionvariable2 = data.cleaned$within2)
                  
                } #for 3 within
                if(is.na(within3) == FALSE){
                  data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 3, conditionvariable2 = data.cleaned$within2, conditionvariable3 = data.cleaned$within3)
                }
                
                
                #for 2 within and 1 between
                if(is.na(between1) == FALSE){
                  data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 3, conditionvariable2 = data.cleaned$within2, conditionvariable3 = data.cleaned$between1)
                  
                  #for 3 within and 1 between
                  if(is.na(within3) == FALSE){
                    data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 4, conditionvariable2 = data.cleaned$within2, conditionvariable3 = data.cleaned$within3, conditionvariable4 = between1)
                    
                  }
                }
              }#for 1 within and 1 between
              if(is.na(between1) == FALSE){
                data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 2, conditionvariable2 = data.cleaned$between1)
              }
              
              
              
              #make factors a factor for the anova
              data.aggregated$participant <- as.factor(data.aggregated$participant)
              data.aggregated$within1 <- as.factor(data.aggregated$within1)
              data.aggregated$within2 <- as.factor(data.aggregated$within2)
              data.aggregated$within3 <- as.factor(data.aggregated$within3)
              data.aggregated$between1 <- as.factor(data.aggregated$between1)
              
              length <- nrow(data.transformed.datatrimmed.fixedtrimmed)
              
              
              
              #run ANOVA
              if(is.na(within2) == FALSE){
                #2 within
                if(is.na(between1) == TRUE) {
                  ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2))
                }
                #3 within
                if(is.na(within3) == FALSE){
                  ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2, within3))
                  
                }
                #2 within 1 between
                if(is.na(between1) == FALSE){
                  ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2), between = .(between1))
                  
                  
                  #3 within 1 between
                  if(is.na(within3) == FALSE){
                    ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2, within3), between = .(between1))
                }
                
                }
              }
              #1 within 1 between
              if(is.na(between1) == FALSE){
                ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1), between = .(between1))
              } #1 within
              if(is.na(between1) == TRUE){
                if(is.na(within2) == TRUE){
                  ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1))
                }
              }
       
              #prepare variables for final dataframe
              model <- ezAnova$ANOVA$Effect
              t.value <- ezAnova$ANOVA$F
              p.value <- ezAnova$ANOVA$p
              Dfn <- ezAnova$ANOVA$DFn
              Dfd <- ezAnova$ANOVA$DFd
              df <- paste(Dfn, Dfd)
              
              #calculate partial eta squared following the formula from Lakens 2013. 
              
              estimate <- (t.value * Dfn) / (t.value * Dfn + Dfd)
              
              
              
              #save data
              anova.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length,df, t.value, p.value, estimate, model))
              
              newdata <- as.data.frame(rbind(newdata, anova.data))
              
            }#end max in numberfixed.max loop
          }#end min in numberfixed.min loop
        }#close fixed trimming loop
        
        #####Begin else loop####  
      } else{ #close if-clause no data-based trimming 
        #set up if clause: Data-Based Trimming:
        #loop through all the options for numberdata
        for(n in numberdata){
          
          data.transformed.datatrimmed <- trim.data.master(type = datatrimming, dataframe = data.transformed, valuevariable = data.transformed$RTvariable, conditionvariable = conditionvariable, idvariable = idvariable, overall.mean.sd = n, median.MAD = n, condition.mean.sd = n, subject.mean.sd = n, condition.subject.mean.sd = n, iqr = n)
          
          #set up option to trim based on raw data
          if(RawData == FALSE){
            data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$transformed
          }
          if(RawData == TRUE){
            data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$latency
          }#close trim based on raw data setup  
          for (fixedtrimming in typesfixedtrimming){
            #set up else clause if there is fixed trimming
            
            #prepare variables for looping
            if (fixedtrimming == "min"){
              numberfixed.max <- NA
              numberfixed.min <- numberfixed.min.s
            }#close fixed trimming min
            if (fixedtrimming == "max"){
              numberfixed.min <- NA
              numberfixed.max <- numberfixed.max.s
            }#close fixed trimming max
            if (fixedtrimming == "minmax"){
              numberfixed.min <- numberfixed.min.s
              numberfixed.max <- numberfixed.max.s
            }#close fixed trimming minmax
            if (fixedtrimming == "nofixedtrimming"){
              numberfixed.min <- NA
              numberfixed.max <- NA
            }#close nofixedtrimming
            
            for (min in numberfixed.min){
              for (max in numberfixed.max) {
                data.transformed.datatrimmed.fixedtrimmed <- trim.fixed.master(type = fixedtrimming, data.transformed.datatrimmed, data.transformed.datatrimmed$RTvariable, min = min, max = max)  
                
                #assign min and max if no fixed trimming
                if(fixedtrimming == "nofixedtrimming"){
                  min <- NA
                  max <- NA
                }#close if no fixed trimming assign min&max
                
                
                #remove participants that do not have data in both groups
                groups1 <- aggregate(
                  within1 ~ participant,
                  data.transformed.datatrimmed.fixedtrimmed,
                  function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within1)))
                )
                
                compliant_participants1 <- groups1[which(groups1$within1),][["participant"]]
                
                
                #if we only have 1 within factor
                if(is.na(within2) == TRUE){
                  data.cleaned <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants1,] 
                }
                
                #if there is a second one, also check for that one              
                if(is.na(within2) == FALSE){
                  #if you have 2 within factors
                  if(is.na(within3) == TRUE){
                    data.cleaned.prelim <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants1,]
                    
                    groups2 <- aggregate(
                      within2 ~ participant,
                      data.transformed.datatrimmed.fixedtrimmed,
                      function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within2)))
                    )
                    
                    compliant_participants2 <- groups2[which(groups2$within2),][["participant"]]
                    data.cleaned <- data.cleaned.prelim[data.cleaned.prelim$participant %in% compliant_participants2,]
                    
                    
                    
                  }
                  #if you have 3 within factors
                  if(is.na(within3) == FALSE){
                    data.cleaned.prelim <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants1,]
                    
                    groups2 <- aggregate(
                      within2 ~ participant,
                      data.transformed.datatrimmed.fixedtrimmed,
                      function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within2)))
                    )
                    
                    compliant_participants2 <- groups2[which(groups2$within2),][["participant"]]
                    data.cleaned.prelim2 <- data.cleaned.prelim[data.cleaned.prelim$participant %in% compliant_participants2,]
                    
                    
                    
                    #and again for the third factor
                    
                    groups3 <- aggregate(
                      within3 ~ participant,
                      data.transformed.datatrimmed.fixedtrimmed,
                      function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$within3)))
                    )
                    
                    compliant_participants3 <- groups3[which(groups3$within3),][["participant"]]
                    data.cleaned <- data.cleaned.prelim2[data.cleaned.prelim2$participant %in% compliant_participants3,]
                    
                    
                    
                    
                    
                    
                    
                    
                  }
                  
                  
                }
                
                
                
                #aggregate data 
                #for 1 within factor
                data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1,data.cleaned$participant, nFactors = 1)
                
                
                if(is.na(within2) == FALSE){
                  #for 2 within
                  if(is.na(between1) == TRUE){
                    data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 2, conditionvariable2 = data.cleaned$within2)
                    
                  } #for 3 within
                  if(is.na(within3) == FALSE){
                    data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 3, conditionvariable2 = data.cleaned$within2, conditionvariable3 = data.cleaned$within3)
                  }
                  
                  
                  #for 2 within and 1 between
                  if(is.na(between1) == FALSE){
                    data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 3, conditionvariable2 = data.cleaned$within2, conditionvariable3 = data.cleaned$between1)
                    
                    #for 3 within and 1 between
                    if(is.na(within3) == FALSE){
                      data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 4, conditionvariable2 = data.cleaned$within2, conditionvariable3 = data.cleaned$within3, conditionvariable4 = between1)
                      
                    }
                  }
                }
                }#for 1 within and 1 between
                if(is.na(between1) == FALSE){
                  data.aggregated <- data_aggregation(data.cleaned, data.cleaned$within1, data.cleaned$participant, nFactors = 2, conditionvariable2 = data.cleaned$between1)
                }
                
                
                
                #make factors a factor for the anova
                data.aggregated$participant <- as.factor(data.aggregated$participant)
                data.aggregated$within1 <- as.factor(data.aggregated$within1)
                data.aggregated$within2 <- as.factor(data.aggregated$within2)
                data.aggregated$within3 <- as.factor(data.aggregated$within3)
                data.aggregated$between1 <- as.factor(data.aggregated$between1)
                
                length <- nrow(data.transformed.datatrimmed.fixedtrimmed)
                #prepare anova
                
                
                #run ANOVA
                #run ANOVA
                if(is.na(within2) == FALSE){
                  #2 within
                  if(is.na(between1) == TRUE) {
                    ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2))
                  }
                  #3 within
                  if(is.na(within3) == FALSE){
                    ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2, within3))
                    
                  }
                  #2 within 1 between
                  if(is.na(between1) == FALSE){
                    ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2), between = .(between1))
                    
                    
                    #3 within 1 between
                    if(is.na(within3) == FALSE){
                      ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1, within2, within3), between = .(between1))
                    }
                    
                  }
                  #1 within 1 between
                  if(is.na(between1) == FALSE){
                    ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1), between = .(between1))
                  } #1 within
                  if(is.na(between1) == TRUE){
                    if(is.na(within2) == TRUE){
                      ezAnova <- ezANOVA(data = data.aggregated, dv = .(latency), wid = .(participant), within = .(within1))
                    }
                  }
                
                
                
                
                
                #prepare variables for final dataframe
                model <- ezAnova$ANOVA$Effect
                t.value <- ezAnova$ANOVA$F
                p.value <- ezAnova$ANOVA$p
                Dfn <- ezAnova$ANOVA$DFn
                Dfd <- ezAnova$ANOVA$DFd
                ef <- paste(Dfn, Dfd)
                
                #calculate partial eta squared following the formula from Lakens 2013. 
                
                estimate <- (t.value * Dfn) / (t.value * Dfn + Dfd)
                
                
                
                #save data
                anova.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length,df, t.value, p.value, estimate, model))
                
                
                newdata <- as.data.frame(rbind(newdata, anova.data))
                #set up choice between analyses
                
                
              }#end max in numberfixed.max loop
            }#end min in numberfixed.min loop
            
            
            
            
          }#close fixed trimming loop
          
          
        }#close for loop n in numberdata
        
        
        
        
      }#close else loop data-based trimming
      
    }#close data-based trimming loop
    
    
  }#close transformation loop
  ####Final Touches on the Dataframe####  
  #change variable types
  newdata$p.value <- as.numeric(as.character(newdata$p.value))
  newdata$t.value <- as.numeric(as.character(newdata$t.value))
  newdata$estimate <- as.numeric(as.character(newdata$estimate))
  newdata$df<- as.character(newdata$df)
 # newdata$Dfn <- as.numeric(as.character(newdata$Dfn))
  newdata$min <- as.numeric(as.character(newdata$min))
  newdata$max <- as.numeric(as.character(newdata$max))
  newdata$length <- as.numeric(as.character(newdata$length))
  newdata$n <- as.numeric(as.character(newdata$n))
  newdata$transformation <- as.factor(newdata$transformation)
  newdata$datatrimming <- as.factor(newdata$datatrimming)
  newdata$fixedtrimming <- as.factor(newdata$fixedtrimming)
  newdata <- newdata %>% 
    dplyr::rename(
      DispersionMeasure = n,
      NumberOfTrials = length
    )
  #write dataframe
  
  return(as.data.frame(newdata)) 
  
}#close function loop



