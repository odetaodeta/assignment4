#######This source file contains all functions related to fixed trimming for the Shiny App pre-process.######

#based on an absolute cut-off: maximum#

trim.max <- function(dataframe, valuevariable, cutoff) { #it takes a dataframe and a cut-off value as input
  trimmed <- dataframe %>% filter(valuevariable < cutoff) #it assigns a new dataframe consisting of all values smaller than the cut-off. Do not use subset in a function
  return(as.data.frame(trimmed)) #allows the output to be saved as dataframe
}

#try out function



#based on an absolute cut-off: minimum#
trim.min <- function(dataframe, valuevariable, cutoff) { #it takes a dataframe column and a cut-off value as input
  trimmed <- dataframe %>% filter(valuevariable > cutoff) #it assigns a new dataframe consisting of all values larger than the cut-off. Do not use subset in a function
  return(as.data.frame(trimmed)) #allows the output to be saved as dataframe
}




#For both absolute cut-offs, our participants should be able to specify the cut-off
#for all mean-based procedures you remove xy SDs +/- the respective mean


#Minimum + Maximum
trim.min.max <- function(dataframe, valuevariable, min, max) {
  trimmed <- dataframe %>% filter(valuevariable > min & valuevariable < max) #it assigns a new dataframe consisting of all values larger than the min and smaller than max.
  return(as.data.frame(trimmed)) #allows the output to be saved as dataframe
  
  
}




#create convenience function with all types of fixed boundaries
trim.fixed.master <- function(type = c("nofixedtrimming", "min", "max", "minmax"), dataframe, valuevariable, min, max){
  if (type == "nofixedtrimming"){
    trimmed <- dataframe
    
  }
  if (type == "min"){
    trimmed <- trim.min(dataframe, valuevariable, min)
  }
  
  if (type == "max"){
    trimmed <- trim.max(dataframe, valuevariable, max)
    
  }
  if (type == "minmax"){
    trimmed <- trim.min.max(dataframe, valuevariable, min, max)
    
  }
  return(as.data.frame(trimmed))
}
