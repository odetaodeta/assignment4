##########This file contains convenience functions for the Shiny app Pre-process#########

#convenience function to create an aggregated dataset containing the means of the original dataset. 
data_aggregation <- function(dataframe, conditionvariable, idvariable, nFactors = c("1", "2", "3", "4"), conditionvariable2 = NA, conditionvariable3 = NA, conditionvariable4 = NA){
  
  if(nFactors == "1"){
  df_aggregated <- aggregate(dataframe, by = list(conditionvariable, idvariable), FUN = mean)
  }

  if(nFactors == "2"){
    df_aggregated <- aggregate(dataframe, by = list(conditionvariable, conditionvariable2, idvariable), FUN = mean)
  }
  
  if(nFactors == "3"){
    df_aggregated <- aggregate(dataframe, by = list(conditionvariable, conditionvariable2, conditionvariable3, idvariable), FUN = mean)
  }
  if(nFactors == "4"){
    df_aggregated <- aggregate(dataframe, by = list(conditionvariable, conditionvariable2, conditionvariable3, conditionvariable4, idvariable), FUN = mean)
  }
  #aggregate the dataset. This creates additional columns we want to get rid of.
  
  #get names columns of input dataframe
  colnamesdataframe <- colnames(dataframe)
  #create an empty dataframe with one variable being the same length as the aggregated dataframe
  df_semi <- as.data.frame(seq.int(nrow(df_aggregated)))
  
  
  #creates a for loop that selects all variables that were in the original dataframe and adds them to the new dataframe.
  for(i in colnamesdataframe){
    df_temp <- dplyr::select(df_aggregated, all_of(i))
    df_semi <- as.data.frame(cbind(df_semi, df_temp))
    
    
    
  }
  #the data still contains the variable we added. I tried to remove it, didn?t work.
  
  #makes it saveable as dataframe
  return(as.data.frame(df_semi))
  
  
  
}
######We need to make sure that the data is in the right format: num for dv, int for the factors

#convenience function that does a t-test based on a condition variable, a dataframe, and a valuevariable. works on both raw and aggregated data. Shiny version that outputs pretty text



###paired ttest


ttest.paired <- function(dataframe, valuevariable, conditionvariable) {
  conditions <- unique(conditionvariable)
  
  ttest <- t.test(as.numeric(valuevariable[conditionvariable == conditions[1]]), as.numeric(valuevariable[conditionvariable == conditions[2]]), paired = TRUE)
  return(ttest)
  
  
}



#bayesian versions

ttest.bayes<- function(dataframe, valuevariable, conditionvariable) {
  conditions <- unique(conditionvariable)
  
  ttest <- ttestBF(as.numeric(valuevariable[conditionvariable == conditions[1]]), as.numeric(valuevariable[conditionvariable == conditions[2]]), paired = TRUE)
  BF <- extractBF(ttest)
  BF_dat <- as.data.frame(BF)
  bf <- BF_dat$bf
  return(as.data.frame(bf))
  
}

#This works in the multiverse function, the other one is for the shiny app.
ttest.bayes2<- function(dataframe, valuevariable, conditionvariable) {
  conditions <- unique(conditionvariable)
  
  ttest <- ttestBF(as.numeric(valuevariable[conditionvariable == conditions[1]]), as.numeric(valuevariable[conditionvariable == conditions[2]]), paired = TRUE)
 return(ttest)
  
}


#function that makes summarystats and returns them as new dataframe
summarystats <- function(dataframe, valuevariable, conditionvariable){
  conditions <- unique(conditionvariable)
  summarydata <- data.frame()
  
  for (i in conditions){
    mean <- round(mean(valuevariable[conditionvariable == i]),2)
    median <- round(median(valuevariable[conditionvariable == i]),2)
    sd <- round(sd(valuevariable[conditionvariable == i]),2)
    mad <- round(mad(valuevariable[conditionvariable == i]),2)
    group <- i
    n <- count(dataframe[conditionvariable == i,])
    tempdata <- as.data.frame(cbind(mean, median, sd, mad, n, group))
    summarydata <- rbind(summarydata, tempdata)
  }

    return(as.data.frame(summarydata))
}


#creates new variables or replaces variables by Group, latency, and participant
data.rename <- function(dataframe, valuevariable, conditionvariable = NA, idvariable, within1 = NA, within2 = NA, within3 = NA,  between1 = NA, testtype = c("t.test", "anova")){
  df <- data.frame()
  latency <- dataframe[valuevariable]
  participant <- dataframe[idvariable]
  
  if(testtype == "t.test"){
    Group <- dataframe[conditionvariable]
    variables <- as.data.frame(cbind(Group, latency, participant))
    names(variables)[1] <- "Group"
    names(variables)[2] <- "latency"
    names(variables)[3] <- "participant"
   
  }
  if(testtype == "anova"){
    within1 <- dataframe[within1]
    
    if(is.na(within2) == FALSE){
      within2 <- dataframe[within2]
    }
    if(is.na(between1) == FALSE){
      between1 <- dataframe[between1]
    }
    if(is.na(within3) == FALSE){
      within3 <-  dataframe[within3]
      
      
      
    }
    {
      
      between1 <- between1
      within2 <- within2
      within3 <- within3
    }
    variables <- as.data.frame(cbind(within1, within2, within3, between1, latency, participant))
    names(variables)[1] <- "within1"
    names(variables)[2] <- "within2"
    names(variables)[3] <- "within3"
    names(variables)[4] <- "between1"
    names(variables)[5] <- "latency"
    names(variables)[6] <- "participant"
  }


  df <- as.data.frame(rbind(df, variables))
  
  return(as.data.frame(df))
  
}

#special version for thesis:
data.rename2 <- function(dataframe, valuevariable, conditionvariable = NA, conditionvariable2 = NA, idvariable, within1 = NA, within2 = NA, within3 = NA,  between1 = NA, testtype = c("t.test", "anova")){
  df <- data.frame()
  latency <- dataframe[valuevariable]
  participant <- dataframe[idvariable]
  
  if(testtype == "t.test"){
    Group <- dataframe[conditionvariable]
    Group2 <- dataframe[conditionvariable2]
    variables <- as.data.frame(cbind(Group, latency, participant, Group2))
    names(variables)[1] <- "Group"
    names(variables)[2] <- "latency"
    names(variables)[3] <- "participant"
    names(variables)[4] <- "Group2"
    
  }
  if(testtype == "anova"){
    within1 <- dataframe[within1]
    
    if(is.na(within2) == FALSE){
      within2 <- dataframe[within2]
    }
    if(is.na(between1) == FALSE){
      between1 <- dataframe[between1]
    }
    if(is.na(within3) == FALSE){
      within3 <-  dataframe[within3]
      
      
      
    }
    {
      
      between1 <- between1
      within2 <- within2
      within3 <- within3
    }
    variables <- as.data.frame(cbind(within1, within2, within3, between1, latency, participant))
    names(variables)[1] <- "within1"
    names(variables)[2] <- "within2"
    names(variables)[3] <- "within3"
    names(variables)[4] <- "between1"
    names(variables)[5] <- "latency"
    names(variables)[6] <- "participant"
  }
  
  
  df <- as.data.frame(rbind(df, variables))
  
  return(as.data.frame(df))
  
}
