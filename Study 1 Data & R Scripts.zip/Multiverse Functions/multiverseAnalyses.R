###This file contains functions that allow for multiverse analyses######

#a function that does a multiverse analysis based on the different transformation types and data-based trimming types available.
options(scipen = 999)


multiverse.t.test <-  function(dataframe, valuevariable, idvariable, conditionvariable, TransformationTypes = c("raw", "inverse", "log", "normal", "square", "squareroot"),  FixedTrimmingTypes = c("min", "max", "minmax", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad", "overall.mean", "condition.mean", "subject.mean", "condition.subject.mean", "iqr"), TestTypes = c("freq.t.test", "bayes.t.test"), data.lower = 2, data.upper = 3, data.step =0.5, fixed.min.lower = 0, fixed.min.upper = 2, fixed.min.step = 0.1, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE){
  ####Setup up variables#####
  
  #takes the number input and turns them into iterable objects
  numberdata <- seq(data.lower, data.upper, data.step) 
  numberfixed.min.s <- seq(fixed.min.lower, fixed.min.upper, fixed.min.step)
  numberfixed.max.s <- seq(fixed.max.lower, fixed.max.upper, fixed.max.step)
  
  #rename columns so that the function works regardless of the input dataset
  data.renamed <- data.rename(dataframe, valuevariable = valuevariable, conditionvariable = conditionvariable, idvariable = idvariable, testtype = "t.test")
  
  #further preparations
  conditions <- unique(conditionvariable) #get levels of conditionvariable
  newdata <- data.frame() #make an empty dataframe
  
  #make iterable objects of the user decisions regarding which transformations and trimming procedures to aply
  

    typestransform <- TransformationTypes

    typesdatatrimming <- DataTrimmingTypes

    typesfixedtrimming <- FixedTrimmingTypes

  
  
  ####Main Loop#####
  for (transformation in typestransform){
    #create a first dataset based on the chosen transformations.
    data.transformed <- transform.master(type = transformation, data.renamed, valuevariable = data.renamed$latency, idvariable = data.renamed$participant)
    
    #set up option to trim based on raw data
    if(RawData == FALSE){
      data.transformed$RTvariable <- data.transformed$transformed
    }
    if(RawData == TRUE){
      data.transformed$RTvariable <- data.transformed$latency
    }#close trim based on raw data setup
    
    #set up data-based trimming loop
    for (datatrimming in typesdatatrimming){
      #set up if clause: No data-based trimming:
      if (datatrimming == "notrimming"){
        data.transformed.datatrimmed <- trim.data.master(type = datatrimming, dataframe = data.transformed, valuevariable = data.transformed$RTvariable, conditionvariable = conditionvariable, idvariable = idvariable)
        n <- NA
        #set up option to trim based on raw data
        if(RawData == FALSE){
          data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$transformed
        }
        if(RawData == TRUE){
          data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$latency
        }#close trim based on raw data setup
        #set up fixed trimming loop
        for (fixedtrimming in typesfixedtrimming){
          #set up else clause if there is fixed trimming
          
          #prepare variables for looping
          if (fixedtrimming == "min"){
            numberfixed.max <- NA
            numberfixed.min <- numberfixed.min.s
          }#close fixed trimming min
          if (fixedtrimming == "max"){
            numberfixed.min <- NA
            numberfixed.max <- numberfixed.max.s
          }#close fixed trimming max
          if (fixedtrimming == "minmax"){
            numberfixed.min <- numberfixed.min.s
            numberfixed.max <- numberfixed.max.s
          }#close fixed trimming minmax
          if (fixedtrimming == "nofixedtrimming"){
            numberfixed.min <- NA
            numberfixed.max <- NA
          }#close nofixedtrimming
          
          for (min in numberfixed.min){
            for (max in numberfixed.max) {
              data.transformed.datatrimmed.fixedtrimmed <- trim.fixed.master(type = fixedtrimming, data.transformed.datatrimmed, data.transformed.datatrimmed$RTvariable, min = min, max = max)  
              
              #assign min and max if no fixed trimming
              if(fixedtrimming == "nofixedtrimming"){
                min <- NA
                max <- NA
              }#close if no fixed trimming assign min&max
              
            
              
              #remove participants that do not have data in both groups
              groups <- aggregate(
                Group ~ participant,
                data.transformed.datatrimmed.fixedtrimmed,
                function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$Group)))
              )
              
              compliant_participants <- groups[which(groups$Group),][["participant"]]
              data.cleaned <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants,]
              
              
                #aggregate data
              data.aggregated <- data_aggregation(data.cleaned, data.cleaned$Group,data.cleaned$participant, nFactors = 1)
              
              
              
              
                #calculate Cohen?s d
                cohensd <- cohen.d(transformed ~ as.factor(Group) |Subject(participant), data.aggregated, paired = TRUE)
                estimate <- cohensd$estimate
                length <- nrow(data.transformed.datatrimmed.fixedtrimmed)
                #set up choice between analyses
                if (TestTypes == "freq.t.test"){
                  #do ttest
                  ttest <- ttest.paired(data.aggregated, data.aggregated$transformed, data.aggregated$Group)
                  #extract parameters
                  p.value <- ttest$p.value
                  t.value <- ttest$statistic
                  df <- ttest$parameter
                  #save the data
                  ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, df, t.value, p.value, estimate))
                  newdata <- as.data.frame(rbind(newdata, ttest.data))
                  
                  
                }#close if clause frequentist
                if (TestTypes == "bayes.t.test"){
                  #do ttest
                  ttest <- ttest.bayes2(data.aggregated, data.aggregated$transformed, data.aggregated$Group)
                  #extract parameters
                  ttestbayes <- extractBF(ttest)
                  bf <- ttestbayes$bf
                  error <- ttestbayes$error
                  #safe data
                  ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, bf, error, estimate))
                  newdata <- as.data.frame(rbind(newdata, ttest.data))
                }#close if clause bayes 
              
                
         
            }#end max in numberfixed.max loop
          }#end min in numberfixed.min loop
        }#close fixed trimming loop
        
      #####Begin else loop####  
      } else{ #close if-clause no data-based trimming 
        #set up if clause: Data-Based Trimming:
        #loop through all the options for numberdata
        for(n in numberdata){
          
          data.transformed.datatrimmed <- trim.data.master(type = datatrimming, dataframe = data.transformed, valuevariable = data.transformed$RTvariable, conditionvariable = conditionvariable, idvariable = idvariable, overall.mean.sd = n, median.MAD = n, condition.mean.sd = n, subject.mean.sd = n, condition.subject.mean.sd = n, iqr = n)
          
          #set up option to trim based on raw data
          if(RawData == FALSE){
            data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$transformed
          }
          if(RawData == TRUE){
            data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$latency
          }#close trim based on raw data setup  
          for (fixedtrimming in typesfixedtrimming){
            #set up else clause if there is fixed trimming
            
            #prepare variables for looping
            if (fixedtrimming == "min"){
              numberfixed.max <- NA
              numberfixed.min <- numberfixed.min.s
            }#close fixed trimming min
            if (fixedtrimming == "max"){
              numberfixed.min <- NA
              numberfixed.max <- numberfixed.max.s
            }#close fixed trimming max
            if (fixedtrimming == "minmax"){
              numberfixed.min <- numberfixed.min.s
              numberfixed.max <- numberfixed.max.s
            }#close fixed trimming minmax
            if (fixedtrimming == "nofixedtrimming"){
              numberfixed.min <- NA
              numberfixed.max <- NA
            }#close nofixedtrimming
            
            for (min in numberfixed.min){
              for (max in numberfixed.max) {
                data.transformed.datatrimmed.fixedtrimmed <- trim.fixed.master(type = fixedtrimming, data.transformed.datatrimmed, data.transformed.datatrimmed$RTvariable, min = min, max = max)  
                
                #assign min and max if no fixed trimming
                if(fixedtrimming == "nofixedtrimming"){
                  min <- NA
                  max <- NA
                }#close if no fixed trimming assign min&max
                
                
                  #remove participants who are not in both groups
                groups <- aggregate(
                  Group ~ participant,
                  data.transformed.datatrimmed.fixedtrimmed,
                  function(x) all(sort(unique(x)) == sort(unique(data.transformed.datatrimmed.fixedtrimmed$Group)))
                )
                
                compliant_participants <- groups[which(groups$Group),][["participant"]]
                data.cleaned <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants,]
                
                
                #aggregate data
                data.aggregated <- data_aggregation(data.cleaned, data.cleaned$Group,data.cleaned$participant, nFactors = 1)
                 
                   #calculate Cohen?s d
                  cohensd <- cohen.d(transformed ~ as.factor(Group) |Subject(participant), data.aggregated, paired = TRUE)
                  estimate <- cohensd$estimate
                  length <- nrow(data.transformed.datatrimmed.fixedtrimmed)
                  #set up choice between analyses
                  if (TestTypes == "freq.t.test"){
                    #do ttest
                    ttest <- ttest.paired(data.aggregated, data.aggregated$transformed, data.aggregated$Group)
                    #extract parameters
                    p.value <- ttest$p.value
                    t.value <- ttest$statistic
                    df <- ttest$parameter
                    #save the data
                    ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, df, t.value, p.value, estimate))
                    newdata <- as.data.frame(rbind(newdata, ttest.data))
                    
                    
                  }#close if clause frequentist
                  if (TestTypes == "bayes.t.test"){
                    #do ttest
                    ttest <- ttest.bayes2(data.aggregated, data.aggregated$transformed, data.aggregated$Group)
                    #extract parameters
                    ttestbayes <- extractBF(ttest)
                    bf <- ttestbayes$bf
                    error <- ttestbayes$error
                    #safe data
                    ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, bf, error, estimate))
                    newdata <- as.data.frame(rbind(newdata, ttest.data))
                  }#close if clause bayes 
                  
                 
                  
              }#end max in numberfixed.max loop
            }#end min in numberfixed.min loop
            
            
            
            
          }#close fixed trimming loop
          
          
        }#close for loop n in numberdata
        
        
        
        
      }#close else loop data-based trimming
      
    }#close data-based trimming loop
    

  }#close transformation loop
####Final Touches on the Dataframe####  
  #change variable types
  if(TestTypes == "freq.t.test"){
    newdata$p.value <- as.numeric(as.character(newdata$p.value))
    newdata$t.value <- as.numeric(as.character(newdata$t.value))
    newdata$df <- as.character(newdata$df)
  }#close testtypes frequentist changing type
  
  if(TestTypes == "bayes.t.test"){
    newdata$bf <- as.numeric(as.character(newdata$bf))
    newdata$error <- as.numeric(as.character(newdata$error))
  }#close if testypes bayes changing types
  
  #change and rename some more variables
  newdata$estimate <- as.numeric(as.character(newdata$estimate))
  newdata$min <- as.numeric(as.character(newdata$min))
  newdata$max <- as.numeric(as.character(newdata$max))
  newdata$length <- as.numeric(as.character(newdata$length))
  newdata$n <- as.numeric(as.character(newdata$n))
  newdata$transformation <- as.factor(newdata$transformation)
  newdata$datatrimming <- as.factor(newdata$datatrimming)
  newdata$fixedtrimming <- as.factor(newdata$fixedtrimming)
  newdata <- newdata %>% 
    dplyr::rename(
      DispersionMeasure = n,
      NumberOfTrials = length
    )
  #write dataframe
  newdata$model <- as.character("NA")
  
  return(as.data.frame(newdata)) 
  
}#close function loop




#specification curve summary plot
#plot from: https://dcosme.github.io/2019/02/26/specification-curve-example/
###I cannot recreate the second plot with our data. Would be great if you can have a run at that.####
multiverse.specificationcurve <- function(dataframe, statistic, alpha = 0.05, threshold = 6, type = c("frequentist", "bayes")){
  
  #Here, the ordering does not work, too. This function needs massive updating.
  if(type == "frequentist"){
    df <- dataframe
    # p <- dataframe[statistic]
    df_ordered <- df[order(df[statistic]),] %>% mutate(uniqueID = row_number(),
                                                significant = ifelse(p.value < alpha, "yes", "no"))
    
    curve <- ggplot(df_ordered, aes(x = uniqueID, y = p.value, color = significant)) + 
      geom_point(shape = "|", size = 4) +
      geom_hline(yintercept = alpha, linetype = "dashed", color = "red") + 
      geom_text(x = Inf, #adds alpha symbol next to line
                y = alpha, vjust = 1.4,
                label = expression(paste(alpha)), 
                color = "red", check_overlap = TRUE,
                hjust = "inward") +
      scale_color_manual(values = c("black", "red")) +
      labs(x = "Specification Number", y = "p-value\n") + 
      ggtitle("Specification Curve: Overall P-Values") +
      theme_minimal(base_size = 12)+ 
      theme(
        axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        legend.position = "none",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank())
    
    return(curve)
    
  }
  
  if(type == "bayes"){
    df <- dataframe
    df_ordered <- df[order(df[statistic]),] %>% mutate(uniqueID = row_number(),
                                               evidenceHa = ifelse(bf > threshold, "yes", "no"))
    #create ggplot object
    curve <- ggplot(df_ordered, aes(x = uniqueID, y = bf, color = evidenceHa)) +
      geom_point(shape = "|", size = 4) + #add bf10, one line per row
      geom_hline(yintercept = threshold, linetype = "dashed", color = "red") + #treshold line
      geom_text(x = Inf, #adds alpha symbol next to line
                y = threshold, vjust = 1.2,
                label = "Threshold", 
                color = "red", check_overlap = TRUE,
                hjust = "inward") +
      scale_color_manual(values = c("black", "red")) +
      labs(x = "Specification Number", y = "BF10\n") + 
      ggtitle("Specification Curve: Overall BF10") +
      theme_minimal(base_size = 12) +
      theme(
        axis.text = element_text(color = "black"),
        axis.line = element_line(colour = "black"),
        legend.position = "none",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank())
    return(curve)
    
    
  }

}#end specification curve plot



#histogram with density curve for p values and bayes factors
multiverse.histogram <- function(dataframe, statistic, alpha = 0.05, threshold = 6, type = c("frequentist", "bayes")){
  if (type == "frequentist"){
    plot <- ggplot(dataframe, aes(x = statistic)) + 
      geom_histogram(binwidth = 0.01, color = "black", fill = "dodgerblue") + #plots the histogram
      geom_density(alpha = 0.5, fill = "#FF6666") + #adds densityplot
      xlim(0,1) +
      geom_vline(xintercept = alpha, color = "red", linetype = "dashed") + #adds alpha line
      geom_text(x = alpha, hjust = -0.5, #adds alpha symbol next to line
                y = Inf,
                label = expression(paste(alpha)), 
                color = "red", check_overlap = TRUE,
                vjust = "inward") +
      xlab("p-value") + 
      theme_bw() + 
      theme(axis.text = element_text(color = "black"),
            axis.line = element_line(colour = "black"),
            legend.position = "none",
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            panel.border = element_blank(),
            panel.background = element_blank()) 
    return(plot)
    
  }
  if (type == "bayes"){
    plot <- ggplot(dataframe, aes(x = statistic)) + 
      geom_histogram(binwidth = 1, color = "black", fill = "dodgerblue") + #plots the histogram
      geom_density(alpha = 0.5, fill = "#FF6666") + ####the geom density does not display and I don?t know why####
    geom_vline(xintercept = threshold, color = "red", linetype = "dashed") + #adds alpha line
      geom_text(x = threshold, hjust = -0.1, #adds alpha symbol next to line
                y = Inf,
                label = "Threshold", 
                color = "red", check_overlap = TRUE,
                vjust = "inward") +
      xlab("BF10") + 
      theme_bw() + 
      theme(axis.text = element_text(color = "black"),
            axis.line = element_line(colour = "black"),
            legend.position = "none",
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            panel.border = element_blank(),
            panel.background = element_blank())
    return(plot)
  }
}



#plot of p value vs effect size vibration plot
#https://figshare.com/articles/Code_data_and_analysis_script_for_A_Traveler_s_Guide_to_the_Multiverse_Promises_Pitfalls_and_a_Framework_for_the_Evaluation_of_Analytic_Decisions_/12089736 main source

multiverse.vibration <- function(effsize, statistic, alpha = 0.05, threshold = 6, type = c("frequentist", "bayes")){
  
  #assign colours schemes
  point.color <-  rgb(0,76,153, alpha=80, maxColorValue=255)
  contour.color = rgb(60,130,180, alpha=130, maxColorValue=255)
  #vibrations
  vibrations <-  kde2d(effsize, -log10(statistic), n=50)
  
  if (type == "frequentist"){
    
    #do the plotting. 
    plot(effsize, -log10(statistic), type="n", las=1, xlab=expression(paste("Effect size")), ylab=expression(paste("-log"[10],"(",italic("p"),"-value)")), main="", cex.lab=1.35, cex.axis=1.2 ) ####the label of the y axis gets cut off by the picture for no reason whatsoever####
    #add quantile lines
    abline(v=as.numeric(quantile(effsize, probs=0.5)), lty=3, lwd=1.8, col="gray70") 
    abline(h=-log10(as.numeric(quantile(statistic, probs=0.5))), lty=3, lwd=1.8, col="gray70") 
    #add data points
    points(effsize, -log10(statistic), pch=16, col=point.color, cex=1.5) 
    #add "vibrations"
    contour(vibrations, drawlabels=FALSE, nlevels=5, lwd=1.7, col=contour.color, add=TRUE) 
    text(as.numeric(quantile(effsize, probs=0.5)), max(-log10(statistic)), "50", pos=2, col="gray40", cex=1) 
    text(max(effsize), -log10(as.numeric(quantile(statistic, probs=0.5))), "50", pos=3, col="gray40", cex=1) 
    #add alpha line and label
    abline(h=-log10(alpha), lty=3, lwd=1.5, col="red") 
    text(min(effsize), -log10(alpha), expression(paste(alpha)), pos = 1, cex = 1, col = "red")
    
  }
 if (type == "bayes"){
  
   vibrations <-  kde2d(effsize, -log10(statistic), n=50)
   #do the plotting. 
   plot(effsize, -log10(statistic), type="n", las=1, xlab=expression(paste("Effect size")), ylab=expression(paste("-log"[10],"BF10")), main="", cex.lab=1.35, cex.axis=1.2 ) 
   #add quantile lines
   abline(v=as.numeric(quantile(effsize, probs=0.5)), lty=3, lwd=1.8, col="gray70") 
   abline(h=-log10(as.numeric(quantile(statistic, probs=0.5))), lty=3, lwd=1.8, col="gray70") 
   #add data points
   points(effsize, -log10(statistic), pch=16, col=point.color, cex=1.5) 
   #add "vibrations"
   contour(vibrations, drawlabels=FALSE, nlevels=5, lwd=1.7, col=contour.color, add=TRUE) 
   text(as.numeric(quantile(effsize, probs=0.5)), max(-log10(statistic)), "50", pos=2, col="gray40", cex=1) 
   text(max(effsize), -log10(as.numeric(quantile(statistic, probs=0.5))), "50", pos=3, col="gray40", cex=1) 
   #add threshold line and label
   abline(h=-log10(threshold), lty=3, lwd=1.5, col="red") 
   text(min(effsize), -log10(threshold), "BF", pos = 1, cex = 1, offset = 0.1, col = "red")
   
   }
}


#function that calculates the proportion of significant p-values or bf factors above the evidencelimit
multiverse.prop <- function(dataframe, type = c("frequentist", "bayes"), variable,  alpha = 0.05, threshold = 6) {
  #get length total dataframe
  n <- length(variable)
  #create subdataframe with all values smaller than alpha
  if (type == "frequentist"){
    sig.data <- dataframe %>% filter(variable < alpha)
    #get length 
    sig <- nrow(sig.data)
    #calculate proportion
    prop <- sig / n
    return(prop)
  }
  if (type == "bayes"){
    ev.data <- dataframe %>% filter(variable > threshold)
    ev <- nrow(ev.data)
    prop <- ev / n
    return(prop)
  }
}


###New Multiverse Function for Multiverse of Difference Scores. Aimed at my thesis, for other things it may not work####

multiverse.t.test2 <-  function(dataframe, valuevariable, idvariable, conditionvariable, conditionvariable2, TransformationTypes = c("raw", "inverse", "log", "normal", "square", "squareroot"),  FixedTrimmingTypes = c("min", "max", "minmax", "nofixedtrimming"), DataTrimmingTypes = c("notrimming", "mad", "overall.mean", "condition.mean", "subject.mean", "condition.subject.mean", "iqr"), TestTypes = c("freq.t.test", "bayes.t.test"), data.lower = 2, data.upper = 3, data.step =0.5, fixed.min.lower = 0, fixed.min.upper = 2, fixed.min.step = 0.1, fixed.max.lower = 8, fixed.max.upper = 10, fixed.max.step = 0.1, RawData = TRUE){
  ####Setup up variables#####
  
  #takes the number input and turns them into iterable objects
  numberdata <- seq(data.lower, data.upper, data.step) 
  numberfixed.min.s <- seq(fixed.min.lower, fixed.min.upper, fixed.min.step)
  numberfixed.max.s <- seq(fixed.max.lower, fixed.max.upper, fixed.max.step)
  
  #rename columns so that the function works regardless of the input dataset
  data.renamed <- data.rename2(dataframe, valuevariable = valuevariable, conditionvariable = conditionvariable, conditionvariable2 = conditionvariable2, idvariable = idvariable, testtype = "t.test")
  
  #further preparations
  conditions <- unique(conditionvariable) #get levels of conditionvariable
  newdata <- data.frame() #make an empty dataframe
  
  #make iterable objects of the user decisions regarding which transformations and trimming procedures to aply
  
  
  typestransform <- TransformationTypes
  
  typesdatatrimming <- DataTrimmingTypes
  
  typesfixedtrimming <- FixedTrimmingTypes
  
  
  
  ####Main Loop#####
  for (transformation in typestransform){
    #create a first dataset based on the chosen transformations.
    data.transformed <- transform.master(type = transformation, data.renamed, valuevariable = data.renamed$latency, idvariable = data.renamed$participant)
    
    #set up option to trim based on raw data
    if(RawData == FALSE){
      data.transformed$RTvariable <- data.transformed$transformed
    }
    if(RawData == TRUE){
      data.transformed$RTvariable <- data.transformed$latency
    }#close trim based on raw data setup
    
    #set up data-based trimming loop
    for (datatrimming in typesdatatrimming){
      #set up if clause: No data-based trimming:
      if (datatrimming == "notrimming"){
        data.transformed.datatrimmed <- trim.data.master(type = datatrimming, dataframe = data.transformed, valuevariable = data.transformed$RTvariable, conditionvariable = conditionvariable, idvariable = idvariable)
        n <- NA
        #set up option to trim based on raw data
        if(RawData == FALSE){
          data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$transformed
        }
        if(RawData == TRUE){
          data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$latency
        }#close trim based on raw data setup
        #set up fixed trimming loop
        for (fixedtrimming in typesfixedtrimming){
          #set up else clause if there is fixed trimming
          
          #prepare variables for looping
          if (fixedtrimming == "min"){
            numberfixed.max <- NA
            numberfixed.min <- numberfixed.min.s
          }#close fixed trimming min
          if (fixedtrimming == "max"){
            numberfixed.min <- NA
            numberfixed.max <- numberfixed.max.s
          }#close fixed trimming max
          if (fixedtrimming == "minmax"){
            numberfixed.min <- numberfixed.min.s
            numberfixed.max <- numberfixed.max.s
          }#close fixed trimming minmax
          if (fixedtrimming == "nofixedtrimming"){
            numberfixed.min <- NA
            numberfixed.max <- NA
          }#close nofixedtrimming
          
          for (min in numberfixed.min){
            for (max in numberfixed.max) {
              data.transformed.datatrimmed.fixedtrimmed <- trim.fixed.master(type = fixedtrimming, data.transformed.datatrimmed, data.transformed.datatrimmed$RTvariable, min = min, max = max)  
              
              #assign min and max if no fixed trimming
              if(fixedtrimming == "nofixedtrimming"){
                min <- NA
                max <- NA
              }#close if no fixed trimming assign min&max
              
              
              
              
              #remove participants that do not have data in both groups
              #remove participants who are not in both groups
              #recheck again later, something seems to be not working.
              groups <- aggregate(
                Group ~ participant,
                data.transformed.datatrimmed.fixedtrimmed,
                function(x) identical(sort(unique(x)), sort(unique(data.transformed.datatrimmed.fixedtrimmed$Group)))
              )
              
              compliant_participants <- groups[which(groups$Group),][["participant"]]
              
              data.cleaned.group1 <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants,]
              
             
              groups2 <- aggregate(
                Group2 ~ participant,
                data.cleaned.group1 ,
                function(x) identical(sort(unique(x)), sort(unique(data.cleaned.group1$Group2)))
              )
              
              compliant_participants2 <- groups[which(groups2$Group2),][["participant"]]
              
              data.cleaned <- data.cleaned.group1 [data.cleaned.group1$participant %in% compliant_participants2,]
              
              #aggregate data
              data.aggregated2 <- data_aggregation(data.cleaned, data.cleaned$Group,data.cleaned$participant, nFactors = 2, data.cleaned$Group2)
              
              data.aggregated <- reshape2::dcast(data.aggregated2, participant + Group2 ~ Group, value.var = "transformed")
              
              data.aggregated$differencescore <- data.aggregated$`1` - data.aggregated$`2`
              
              
              #calculate Cohen?s d
              
              length <- nrow(data.transformed.datatrimmed.fixedtrimmed)
              #set up choice between analyses
              if (TestTypes == "freq.t.test"){
                #do ttest
                ttest <- ttest.paired(data.aggregated, data.aggregated$differencescore, data.aggregated$Group2)
                #extract parameters
                p.value <- ttest$p.value
                t.value <- ttest$statistic
                df <- ttest$parameter
                cohensd <- cohen.d(differencescore ~ as.factor(Group2) |Subject(participant), data.aggregated, paired = TRUE)
                estimate <- cohensd$estimate
                
                ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, df, t.value, p.value, estimate))
                newdata <- as.data.frame(rbind(newdata, ttest.data))
                
                
              }#close if clause frequentist
              if (TestTypes == "bayes.t.test"){
                #do ttest
                ttest <- ttest.bayes2(data.aggregated, data.aggregated$transformed, data.aggregated$Group)
                #extract parameters
                ttestbayes <- extractBF(ttest)
                bf <- ttestbayes$bf
                error <- ttestbayes$error
                #safe data
                ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, bf, error, estimate))
                newdata <- as.data.frame(rbind(newdata, ttest.data))
              }#close if clause bayes 
              
              
              
            }#end max in numberfixed.max loop
          }#end min in numberfixed.min loop
        }#close fixed trimming loop
        
        #####Begin else loop####  
      } else{ #close if-clause no data-based trimming 
        #set up if clause: Data-Based Trimming:
        #loop through all the options for numberdata
        for(n in numberdata){
          
          data.transformed.datatrimmed <- trim.data.master(type = datatrimming, dataframe = data.transformed, valuevariable = data.transformed$RTvariable, conditionvariable = conditionvariable, idvariable = idvariable, overall.mean.sd = n, median.MAD = n, condition.mean.sd = n, subject.mean.sd = n, condition.subject.mean.sd = n, iqr = n)
          
          #set up option to trim based on raw data
          if(RawData == FALSE){
            data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$transformed
          }
          if(RawData == TRUE){
            data.transformed.datatrimmed$RTvariable <- data.transformed.datatrimmed$latency
          }#close trim based on raw data setup  
          for (fixedtrimming in typesfixedtrimming){
            #set up else clause if there is fixed trimming
            
            #prepare variables for looping
            if (fixedtrimming == "min"){
              numberfixed.max <- NA
              numberfixed.min <- numberfixed.min.s
            }#close fixed trimming min
            if (fixedtrimming == "max"){
              numberfixed.min <- NA
              numberfixed.max <- numberfixed.max.s
            }#close fixed trimming max
            if (fixedtrimming == "minmax"){
              numberfixed.min <- numberfixed.min.s
              numberfixed.max <- numberfixed.max.s
            }#close fixed trimming minmax
            if (fixedtrimming == "nofixedtrimming"){
              numberfixed.min <- NA
              numberfixed.max <- NA
            }#close nofixedtrimming
            
            for (min in numberfixed.min){
              for (max in numberfixed.max) {
                data.transformed.datatrimmed.fixedtrimmed <- trim.fixed.master(type = fixedtrimming, data.transformed.datatrimmed, data.transformed.datatrimmed$RTvariable, min = min, max = max)  
                
                #assign min and max if no fixed trimming
                if(fixedtrimming == "nofixedtrimming"){
                  min <- NA
                  max <- NA
                }#close if no fixed trimming assign min&max
                
                
                #remove participants who are not in both groups
                groups <- aggregate(
                  Group ~ participant,
                  data.transformed.datatrimmed.fixedtrimmed,
                  function(x) identical(sort(unique(x)), sort(unique(data.transformed.datatrimmed.fixedtrimmed$Group)))
                )
                
                compliant_participants <- groups[which(groups$Group),][["participant"]]
                
                data.cleaned.group1 <- data.transformed.datatrimmed.fixedtrimmed[data.transformed.datatrimmed.fixedtrimmed$participant %in% compliant_participants,]
                
                
                groups2 <- aggregate(
                  Group2 ~ participant,
                  data.cleaned.group1 ,
                  function(x) identical(sort(unique(x)), sort(unique(data.cleaned.group1$Group2)))
                )
                
                compliant_participants2 <- groups[which(groups2$Group2),][["participant"]]
                
                data.cleaned <- data.cleaned.group1 [data.cleaned.group1$participant %in% compliant_participants2,]
                #aggregate data
                data.aggregated2 <- data_aggregation(data.cleaned, data.cleaned$Group,data.cleaned$participant, nFactors = 2, data.cleaned$Group2)
                
                data.aggregated <- reshape2::dcast(data.aggregated2, participant + Group2 ~ Group, value.var = "transformed")
               
                
                data.aggregated$differencescore <- data.aggregated$`1` - data.aggregated$`2`
                
                
                #calculate Cohen?s d
               
                length <- nrow(data.transformed.datatrimmed.fixedtrimmed)
                #set up choice between analyses
                if (TestTypes == "freq.t.test"){
                  #do ttest
                  ttest <- ttest.paired(data.aggregated, data.aggregated$differencescore, data.aggregated$Group2)
                  #extract parameters
                  p.value <- ttest$p.value
                  t.value <- ttest$statistic
                  df <- ttest$parameter
                  #save the data
                  cohensd <- cohen.d(differencescore ~ as.factor(Group2) |Subject(participant), data.aggregated, paired = TRUE)
                  estimate <- cohensd$estimate
                  
                  ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, df, t.value, p.value, estimate))
                  newdata <- as.data.frame(rbind(newdata, ttest.data))
                  
                  
                }#close if clause frequentist
                if (TestTypes == "bayes.t.test"){
                  #do ttest
                  ttest <- ttest.bayes2(data.aggregated, data.aggregated$transformed, data.aggregated$Group)
                  #extract parameters
                  ttestbayes <- extractBF(ttest)
                  bf <- ttestbayes$bf
                  error <- ttestbayes$error
                  #safe data
                  ttest.data <- as.data.frame(cbind(transformation, datatrimming, fixedtrimming, min, max, n, length, bf, error, estimate))
                  newdata <- as.data.frame(rbind(newdata, ttest.data))
                }#close if clause bayes 
                
                
                
              }#end max in numberfixed.max loop
            }#end min in numberfixed.min loop
            
            
            
            
          }#close fixed trimming loop
          
          
        }#close for loop n in numberdata
        
        
        
        
      }#close else loop data-based trimming
      
    }#close data-based trimming loop
    
    
  }#close transformation loop
  ####Final Touches on the Dataframe####  
  #change variable types
  if(TestTypes == "freq.t.test"){
    newdata$p.value <- as.numeric(as.character(newdata$p.value))
    newdata$t.value <- as.numeric(as.character(newdata$t.value))
    newdata$df <- as.character(newdata$df)
  }#close testtypes frequentist changing type
  
  if(TestTypes == "bayes.t.test"){
    newdata$bf <- as.numeric(as.character(newdata$bf))
    newdata$error <- as.numeric(as.character(newdata$error))
  }#close if testypes bayes changing types
  
  #change and rename some more variables
  newdata$estimate <- as.numeric(as.character(newdata$estimate))
  newdata$min <- as.numeric(as.character(newdata$min))
  newdata$max <- as.numeric(as.character(newdata$max))
  newdata$length <- as.numeric(as.character(newdata$length))
  newdata$n <- as.numeric(as.character(newdata$n))
  newdata$transformation <- as.factor(newdata$transformation)
  newdata$datatrimming <- as.factor(newdata$datatrimming)
  newdata$fixedtrimming <- as.factor(newdata$fixedtrimming)
  newdata <- newdata %>% 
    dplyr::rename(
      DispersionMeasure = n,
      NumberOfTrials = length
    )
  newdata$model <- as.character("NA")
  #write dataframe
  
  return(as.data.frame(newdata)) 
  
}#close function loop

