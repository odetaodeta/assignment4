############Source file for functions for data-based trimming methods###########

#MAD based trimming
trim.mad <- function(dataframe, valuevariable, numberMAD) {
  median <- median(valuevariable)
  MAD <- mad(valuevariable)
  trimmed <- dataframe %>% filter(valuevariable < (median + MAD * numberMAD) & valuevariable > (median - MAD * numberMAD))
  return(as.data.frame(trimmed))
}




#Overall-mean based

trim.overall.mean <- function(dataframe, valuevariable, numberSD) {
  mean <- mean(valuevariable) #get mean of data
  SD <- sd(valuevariable) #get sd of data
  
  #make a new dataframe consisting of all values larger than mean - sd*numbersd and all values smaller than mean + sd*numbersd
  
  trimmed <- dataframe %>% filter(valuevariable < (mean + SD * numberSD) & valuevariable > (mean - SD * numberSD))
  
  
  
  return(as.data.frame(trimmed)) #allows data to be returned as dataframe
  
}


#Condition-mean based

trim.condition.mean <- function(dataframe, valuevariable, conditionvariable, numberSD){
  
  conditions <- unique(conditionvariable) #get the levels of the condition variable
  
  #initalise empty dataframe
  combineddata <- data.frame()
  
  #main loop
  for (i in conditions) {
    #create subdataframe per condition
    conditiondata <- dataframe %>% filter(conditionvariable == i)
    
    #calculate mean and sd for each condition
    mean <- mean(valuevariable[conditionvariable == i])
    SD <- sd(valuevariable[conditionvariable == i])
    
    #create a trimmed dataset per condition
    trimmed <- conditiondata %>% filter(valuevariable[conditionvariable == i] < (mean + SD * numberSD) & valuevariable[conditionvariable == i] > (mean - SD * numberSD))
    
    #create summarised dataframe
    combineddata <- rbind(combineddata, trimmed)
    
  }
  #return the dataframe
  return(as.data.frame(combineddata))
  
  
  
  
}



#Subject-mean based

trim.subject.mean <- function(dataframe, valuevariable, idvariable, numberSD){
  
  conditions <- unique(idvariable) #get the levels of the participant variable
  
  #initalise empty dataframe
  combineddata <- data.frame()
  
  #main loop
  for (i in conditions) {
    #create subdataframe per condition
    ppdata <- dataframe %>% filter(idvariable== i)
    
    #calculate mean and sd for each condition
    mean <- mean(valuevariable[idvariable == i])
    SD <- sd(valuevariable[idvariable == i])
    
    #create a trimmed dataset per condition
    trimmed <- ppdata %>% filter(valuevariable[idvariable == i] < (mean + SD * numberSD) & valuevariable[idvariable == i] > (mean - SD * numberSD))
    
    #create summarised dataframe
    combineddata <- rbind(combineddata, trimmed)
    
  }
  #return the dataframe
  return(as.data.frame(combineddata))
  
  
  
  
}


#condition-wise subject-mean based
trim.condition.subject.mean <- function(dataframe, valuevariable, conditionvariable, idvariable, numberSD){
  
  conditions <- unique(conditionvariable) #get the levels of the condition variable
  subjects <- unique(idvariable) #get the levels of the idvariable
  
  #initalise empty dataframe
  combineddata <- data.frame()
  
  #main loop
  for (i in conditions) {
    for (x in subjects) {
      conditionsubjectdata <- dataframe %>% filter(conditionvariable == i & idvariable == x) #subdataframe per participant and condition
      mean <- mean(valuevariable[conditionvariable == i & idvariable == x]) #mean per participant and condition
      SD <- sd(valuevariable[conditionvariable == i  & idvariable == x]) #sd per participant and condition
      
      trimmed <- conditionsubjectdata %>% filter(valuevariable[conditionvariable == i & idvariable == x] < (mean + SD * numberSD) & valuevariable[conditionvariable == i & idvariable == x] > (mean - SD * numberSD))
      
      combineddata <- rbind(combineddata, trimmed)
      
    }
  }
  #return the dataframe
  return(as.data.frame(combineddata))
  
  
  
  
}



#proportion based, e.g. exclude the top and bottom x percent
trim.prop <- function(dataframe, valuevariable, bottompercent, toppercent){
  #order the data
  ordered <- dataframe[order(valuevariable),]
  
  #get the number of cases and save them as new variable
  ordered$count <- seq.int(nrow(ordered))
  
  trimmed <- ordered %>% filter(count < length(count) * toppercent & count > length(count) * bottompercent)
  
  
  
  #make dataframe saveable
  return(as.data.frame(trimmed))
}



#IQR based
trim.iqr <- function(dataframe, valuevariable, numberIQR) {
  quart <- quantile(valuevariable, probs = c(0.25, 0.75)) #get mean of data
  IQR <- IQR(valuevariable) #get sd of data
  
  #make a new dataframe consisting of all values larger than mean - IQR*numberIQR and all values smaller than mean + IQR*numberIQR
  
  trimmed <- dataframe %>% filter(valuevariable < (quart[2] + IQR * numberIQR) & valuevariable > (quart[1] - IQR * numberIQR))
  
  
  
  return(as.data.frame(trimmed)) #allows data to be returned as dataframe
  
}

#try out function

#functions that summarises all data based trimming options.
trim.data.master <- function(type = c("notrimming", "mad", "overall.mean", "condition.mean", "subject.mean", "condition.subject.mean", "prop", "iqr"), dataframe, valuevariable, conditionvariable, idvariable, overall.mean.sd = 1, median.MAD = 1, condition.mean.sd = 1, subject.mean.sd = 1, condition.subject.mean.sd = 1, bottompercent = 0.05, toppercent = 0.95, iqr = 2){
  if (type == "notrimming"){
    trimmed <- dataframe
    
  }
  if (type == "mad"){
    
    trimmed <- trim.mad(dataframe, valuevariable, median.MAD)
  }
  if (type == "overall.mean"){
    
    trimmed <- trim.overall.mean(dataframe, valuevariable, overall.mean.sd)
  }
  if (type == "condition.mean"){
    
    trimmed <- trim.condition.mean(dataframe, valuevariable, conditionvariable, condition.mean.sd)
  }
  if (type == "subject.mean"){
    
    trimmed <- trim.subject.mean(dataframe, valuevariable, idvariable, subject.mean.sd)
  }
  if (type == "condition.subject.mean"){
    
    trimmed <- trim.condition.subject.mean(dataframe, valuevariable, conditionvariable, idvariable, condition.subject.mean.sd)
  }
  if (type == "prop"){
    
    trimmed <- trim.prop(dataframe, valuevariable, bottompercent, toppercent)
  }
  if (type == "iqr"){
    
    trimmed <- trim.iqr(dataframe, valuevariable, iqr)
  }
  return(as.data.frame(trimmed))
}

#try it out
