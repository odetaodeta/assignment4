#######Source file that contains all transformation functions#########

#adds new variable "transformed" to dataframe. it is identical to the valuevariable. Makes later processing easier.
transform.raw <- function(dataframe, valuevariable) {
  dataframe[, "transformed"] <- valuevariable
  return(as.data.frame(dataframe))
}



#latency normalisation#
#Based on Gayet & Stein 2017 and the paper I send to you from myself

transform.normal <- function(dataframe, valuevariable, idvariable) {
  
  conditions <- unique(idvariable) #get the levels of the participant variable
  
  #initalise empty dataframe
  combineddata <- data.frame()
  
  #main loop
  for (i in conditions) {
    #create subdataframe per participant
    ppdata <- dataframe %>% filter(idvariable== i)
    #normalise the data by dividing each participants reaction time by their mean reaction time
    normalvar <- valuevariable[idvariable == i] / mean(valuevariable[idvariable == i])
    
    #add to dataframe
    ppdata[, "transformed"] <- normalvar 
    #add to combined dataframe
    combineddata <- rbind(combineddata, ppdata)
    
    
  }
  return(as.data.frame(combineddata))
}




#log transformation#
##potentially find out how to allow people to determine the name of the log variable
transform.log <- function(dataframe, valuevariable) {
  logvar <- log(valuevariable) #creates the natural log of valuevariable
  dataframe[, "transformed"] <- logvar #adds to dataframe
  
  #makes it saveable as dataframe
  return(as.data.frame(dataframe))
}


#raw data#
#No transformation necessary

#inverse transformation#

transform.inverse <- function(dataframe, valuevariable) {
  inversvar <- 1 / valuevariable #calculates inverse
  dataframe[, "transformed"] <- inversvar #adds inverse to dataframe
  #makes it saveable as dataframe
  return(as.data.frame(dataframe))
  
  
}
#try out


#square root transformation
transform.squareroot <- function(dataframe, valuevariable) {
  rootvar <- sqrt(valuevariable) #calculates sqrt
  dataframe[, "transformed"] <- rootvar #adds srqt to dataframe
  #makes it saveable as dataframe
  return(as.data.frame(dataframe))
  
  
}

#square transformation
transform.square <- function(dataframe, valuevariable){
  square <- square(valuevariable) #calculates sqaure
  dataframe[, "transformed"] <- square #adds square to dataframe
  #makes it saveable as dataframe
  return(as.data.frame(dataframe))
}


#master function for app
transform.master <- function(type = c("normal", "log", "inverse", "raw", "squareroot", "square"), dataframe, valuevariable, idvariable) {
  if (type == "normal") {
    transformed <- transform.normal(dataframe, valuevariable, idvariable)
  }
  if (type == "log") {
    transformed <- transform.log(dataframe, valuevariable)
  }
  if (type == "raw") {
    
    transformed <- transform.raw(dataframe, valuevariable)
  }
  if (type == "inverse") {
    transformed <- transform.inverse(dataframe, valuevariable)
  }
  if (type == "squareroot"){
    transformed <- transform.squareroot(dataframe, valuevariable)
  }
  if (type == "square"){
    transformed <- transform.square(dataframe, valuevariable)
  }
  return(as.data.frame(transformed))
}





